// Interactive Math Lab Tools for Visual Exploratory Learning

const MathLab = {
  activeTab: "tenframe",

  init() {
    this.render();
  },

  setTab(tab) {
    this.activeTab = tab;
    this.render();
  },

  render() {
    const container = document.getElementById("mathLabContent");
    if (!container) return;

    if (this.activeTab === "tenframe") {
      this.renderTenFrame(container);
    } else if (this.activeTab === "fraction") {
      this.renderFractionPizza(container);
    } else if (this.activeTab === "balance") {
      this.renderAlgebraBalance(container);
    } else if (this.activeTab === "grapher") {
      this.renderFunctionGrapher(container);
    }
  },

  // 1. Ten Frame Sandbox (Ages 5-7)
  tenFrameCount: 6,
  tenFrameMax: 10,
  tenFrameIcon: "🍎",

  renderTenFrame(container) {
    let cellsHtml = "";
    for (let i = 0; i < this.tenFrameMax; i++) {
      const isFilled = i < this.tenFrameCount;
      cellsHtml += `
        <button onclick="MathLab.toggleTenFrame(${i})" class="w-14 h-14 sm:w-16 sm:h-16 rounded-2xl flex items-center justify-center text-3xl border-2 transition-all transform hover:scale-105 active:scale-95 shadow-sm ${
          isFilled
            ? 'bg-emerald-100 dark:bg-emerald-950/80 border-emerald-400 dark:border-emerald-500 text-emerald-600'
            : 'bg-slate-50 dark:bg-slate-800/50 border-dashed border-slate-300 dark:border-slate-600 text-slate-300'
        }">
          ${isFilled ? this.tenFrameIcon : '○'}
        </button>
      `;
    }

    const needed = this.tenFrameMax - this.tenFrameCount;

    container.innerHTML = `
      <div class="max-w-xl mx-auto space-y-6 text-center animate-fadeIn">
        <div class="flex items-center justify-between flex-wrap gap-2">
          <h3 class="text-xl font-bold text-slate-800 dark:text-slate-100 flex items-center gap-2">
            <span>🔟</span> Ten-Frame Counter (Ages 5–7)
          </h3>
          <div class="flex items-center gap-1 bg-slate-100 dark:bg-slate-800 p-1 rounded-xl">
            ${["🍎", "⭐", "🐼", "🚀", "💎"].map(ic => `
              <button onclick="MathLab.setTenFrameIcon('${ic}')" class="px-2.5 py-1 rounded-lg text-lg hover:bg-white dark:hover:bg-slate-700 transition ${this.tenFrameIcon === ic ? 'bg-white dark:bg-slate-700 shadow-sm' : ''}">${ic}</button>
            `).join("")}
          </div>
        </div>
        <p class="text-sm text-slate-500 dark:text-slate-400">Click any box to fill or empty it. Watch the number bond update automatically!</p>

        <div class="grid grid-cols-5 gap-3 p-5 bg-white dark:bg-slate-900 border border-slate-200 dark:border-slate-800 rounded-3xl shadow-sm justify-items-center">
          ${cellsHtml}
        </div>

        <div class="bg-gradient-to-r from-emerald-500/10 to-teal-500/10 p-5 rounded-2xl border border-emerald-200 dark:border-emerald-800 flex items-center justify-around flex-wrap gap-4 text-center">
          <div>
            <div class="text-xs uppercase font-bold text-slate-500 dark:text-slate-400">Filled</div>
            <div class="text-3xl font-black text-emerald-600 dark:text-emerald-400">${this.tenFrameCount}</div>
          </div>
          <div class="text-2xl font-bold text-slate-400">➕</div>
          <div>
            <div class="text-xs uppercase font-bold text-slate-500 dark:text-slate-400">Empty (Needed)</div>
            <div class="text-3xl font-black text-amber-500">${needed}</div>
          </div>
          <div class="text-2xl font-bold text-slate-400">🟰</div>
          <div>
            <div class="text-xs uppercase font-bold text-slate-500 dark:text-slate-400">Total</div>
            <div class="text-3xl font-black text-blue-600 dark:text-blue-400">10</div>
          </div>
        </div>

        <div class="flex justify-center gap-3">
          <button onclick="MathLab.clearTenFrame()" class="px-4 py-2 text-sm font-semibold text-slate-600 dark:text-slate-300 bg-slate-100 dark:bg-slate-800 hover:bg-slate-200 rounded-xl transition">Clear All</button>
          <button onclick="MathLab.fillTenFrame()" class="px-4 py-2 text-sm font-semibold text-white bg-emerald-600 hover:bg-emerald-700 rounded-xl transition">Fill 10</button>
        </div>
      </div>
    `;
  },

  toggleTenFrame(index) {
    if (index < this.tenFrameCount) {
      this.tenFrameCount = index;
    } else {
      this.tenFrameCount = index + 1;
    }
    soundManager.playPop();
    this.render();
  },

  clearTenFrame() {
    this.tenFrameCount = 0;
    soundManager.playPop();
    this.render();
  },

  fillTenFrame() {
    this.tenFrameCount = 10;
    soundManager.playCorrect();
    this.render();
  },

  setTenFrameIcon(icon) {
    this.tenFrameIcon = icon;
    this.render();
  },

  // 2. Interactive Pizza Fraction (Ages 8-11)
  fractionNum: 3,
  fractionDenom: 8,

  renderFractionPizza(container) {
    const num = this.fractionNum;
    const denom = this.fractionDenom;
    const pct = ((num / denom) * 100).toFixed(1);
    const decimal = (num / denom).toFixed(3);

    // Calculate simplified fraction
    const gcd = (a, b) => b === 0 ? a : gcd(b, a % b);
    const div = gcd(num, denom);
    const simpNum = num / div;
    const simpDenom = denom / div;

    // Generate SVG Pizza Slices
    const radius = 100;
    const cx = 130;
    const cy = 130;
    let pathsHtml = "";

    for (let i = 0; i < denom; i++) {
      const startAngle = (i * 2 * Math.PI) / denom - Math.PI / 2;
      const endAngle = ((i + 1) * 2 * Math.PI) / denom - Math.PI / 2;
      const isSelected = i < num;

      const x1 = cx + radius * Math.cos(startAngle);
      const y1 = cy + radius * Math.sin(startAngle);
      const x2 = cx + radius * Math.cos(endAngle);
      const y2 = cy + radius * Math.sin(endAngle);
      const largeArc = (endAngle - startAngle > Math.PI) ? 1 : 0;

      const d = `M ${cx} ${cy} L ${x1} ${y1} A ${radius} ${radius} 0 ${largeArc} 1 ${x2} ${y2} Z`;

      pathsHtml += `
        <path d="${d}"
              fill="${isSelected ? '#f59e0b' : '#f1f5f9'}"
              stroke="#cbd5e1"
              stroke-width="2.5"
              class="cursor-pointer transition-colors duration-200 hover:opacity-85"
              onclick="MathLab.clickPizzaSlice(${i + 1})" />
      `;
    }

    container.innerHTML = `
      <div class="max-w-xl mx-auto space-y-6 text-center animate-fadeIn">
        <h3 class="text-xl font-bold text-slate-800 dark:text-slate-100 flex items-center justify-center gap-2">
          <span>🍕</span> Pizza Fraction Visualizer (Ages 8–11)
        </h3>
        <p class="text-sm text-slate-500 dark:text-slate-400">Adjust the sliders or click the pizza slices to explore fractions, percentages, and decimals!</p>

        <div class="flex flex-col sm:flex-row items-center justify-center gap-8 bg-white dark:bg-slate-900 p-6 rounded-3xl border border-slate-200 dark:border-slate-800 shadow-sm">
          <svg width="260" height="260" viewBox="0 0 260 260" class="drop-shadow-md">
            <!-- Crust circle -->
            <circle cx="130" cy="130" r="106" fill="#d97706" opacity="0.3" />
            ${pathsHtml}
            <!-- Center pin -->
            <circle cx="130" cy="130" r="12" fill="#b45309" stroke="#fff" stroke-width="3" />
          </svg>

          <div class="space-y-4 text-left w-full sm:w-56">
            <div>
              <label class="text-xs font-bold uppercase text-slate-400">Numerator (Slices Selected): <b class="text-amber-500">${num}</b></label>
              <input type="range" min="0" max="${denom}" value="${num}" oninput="MathLab.setFractionNum(this.value)" class="w-full accent-amber-500 cursor-pointer" />
            </div>

            <div>
              <label class="text-xs font-bold uppercase text-slate-400">Denominator (Total Slices): <b class="text-blue-500">${denom}</b></label>
              <input type="range" min="2" max="16" value="${denom}" oninput="MathLab.setFractionDenom(this.value)" class="w-full accent-blue-500 cursor-pointer" />
            </div>

            <div class="p-3 bg-slate-50 dark:bg-slate-800/60 rounded-xl border border-slate-200 dark:border-slate-700 text-xs space-y-1.5 font-mono">
              <div class="flex justify-between"><span>Fraction:</span> <b class="text-amber-600 dark:text-amber-400">${num} / ${denom}</b></div>
              <div class="flex justify-between"><span>Simplest form:</span> <b class="text-emerald-600 dark:text-emerald-400">${simpNum} / ${simpDenom}</b></div>
              <div class="flex justify-between"><span>Percentage:</span> <b class="text-blue-600 dark:text-blue-400">${pct}%</b></div>
              <div class="flex justify-between"><span>Decimal:</span> <b class="text-purple-600 dark:text-purple-400">${decimal}</b></div>
            </div>
          </div>
        </div>
      </div>
    `;
  },

  setFractionNum(val) {
    this.fractionNum = parseInt(val, 10);
    soundManager.playPop();
    this.render();
  },

  setFractionDenom(val) {
    this.fractionDenom = parseInt(val, 10);
    if (this.fractionNum > this.fractionDenom) {
      this.fractionNum = this.fractionDenom;
    }
    soundManager.playPop();
    this.render();
  },

  clickPizzaSlice(count) {
    this.fractionNum = count;
    soundManager.playPop();
    this.render();
  },

  // 3. Interactive Algebra Balance Scale (Ages 12-14)
  balanceA: 2,
  balanceB: 4,
  balanceC: 10,
  balanceGuessX: 1,

  renderAlgebraBalance(container) {
    const leftVal = this.balanceA * this.balanceGuessX + this.balanceB;
    const rightVal = this.balanceC;
    const diff = leftVal - rightVal;
    const isBalanced = diff === 0;

    // Angle of tilt: clamp between -15 and 15 degrees
    const tiltDeg = Math.max(-14, Math.min(14, diff * 3));

    container.innerHTML = `
      <div class="max-w-xl mx-auto space-y-6 text-center animate-fadeIn">
        <h3 class="text-xl font-bold text-slate-800 dark:text-slate-100 flex items-center justify-center gap-2">
          <span>⚖️</span> Algebra Equation Balancer (Ages 12–14)
        </h3>
        <p class="text-sm text-slate-500 dark:text-slate-400">Balance the scale to solve the linear equation: <b>${this.balanceA}x + ${this.balanceB} = ${this.balanceC}</b></p>

        <!-- Balance Scale Graphic -->
        <div class="relative w-full h-52 bg-white dark:bg-slate-900 border border-slate-200 dark:border-slate-800 rounded-3xl p-4 flex flex-col items-center justify-end overflow-hidden shadow-sm">
          <!-- Fulcrum triangle -->
          <div class="w-0 h-0 border-l-[25px] border-l-transparent border-r-[25px] border-r-transparent border-b-[45px] border-b-slate-700 dark:border-b-slate-300 z-10"></div>
          <div class="w-24 h-3 bg-slate-800 dark:bg-slate-200 rounded-full z-10"></div>

          <!-- Rotating Beam -->
          <div style="transform: rotate(${tiltDeg}deg); transform-origin: center bottom;" class="absolute bottom-[48px] w-72 sm:w-80 h-3 bg-blue-600 rounded-full transition-transform duration-300 ease-out flex justify-between items-center px-4">
            <!-- Left Pan -->
            <div class="relative -top-16 -left-4 flex flex-col items-center">
              <div class="w-0.5 h-12 bg-slate-400"></div>
              <div class="w-24 px-2 py-2 bg-blue-100 dark:bg-blue-900/80 border-2 border-blue-500 rounded-xl shadow text-center text-xs font-mono font-bold">
                <div>${this.balanceA}x + ${this.balanceB}</div>
                <div class="text-blue-600 dark:text-blue-300 text-sm">= ${leftVal}</div>
              </div>
            </div>

            <!-- Right Pan -->
            <div class="relative -top-16 -right-4 flex flex-col items-center">
              <div class="w-0.5 h-12 bg-slate-400"></div>
              <div class="w-24 px-2 py-2 bg-indigo-100 dark:bg-indigo-900/80 border-2 border-indigo-500 rounded-xl shadow text-center text-xs font-mono font-bold">
                <div>Constant</div>
                <div class="text-indigo-600 dark:text-indigo-300 text-sm">= ${rightVal}</div>
              </div>
            </div>
          </div>

          <div class="absolute top-4 font-bold text-sm ${isBalanced ? 'text-emerald-500 animate-pulse' : (diff > 0 ? 'text-amber-500' : 'text-rose-500')}">
            ${isBalanced ? '✨ BALANCED! You found x!' : (diff > 0 ? '⚠️ Left side is heavier!' : '⚠️ Right side is heavier!')}
          </div>
        </div>

        <!-- Slider Controls -->
        <div class="bg-slate-50 dark:bg-slate-800/50 p-5 rounded-2xl border border-slate-200 dark:border-slate-700 max-w-md mx-auto space-y-4">
          <div>
            <div class="flex justify-between text-sm font-semibold mb-1">
              <span>Change unknown <b>x</b>:</span>
              <span class="text-blue-600 font-mono text-base font-bold">x = ${this.balanceGuessX}</span>
            </div>
            <input type="range" min="0" max="10" step="1" value="${this.balanceGuessX}" oninput="MathLab.setBalanceX(this.value)" class="w-full accent-blue-600 cursor-pointer" />
          </div>

          <button onclick="MathLab.newBalanceProblem()" class="w-full py-2.5 bg-blue-600 hover:bg-blue-700 text-white font-semibold rounded-xl text-sm transition">
            Generate New Equation
          </button>
        </div>
      </div>
    `;
  },

  setBalanceX(val) {
    this.balanceGuessX = parseInt(val, 10);
    const leftVal = this.balanceA * this.balanceGuessX + this.balanceB;
    if (leftVal === this.balanceC) {
      soundManager.playCorrect();
    } else {
      soundManager.playPop();
    }
    this.render();
  },

  newBalanceProblem() {
    this.balanceA = randInt(2, 4);
    const trueX = randInt(2, 6);
    this.balanceB = randInt(1, 8);
    this.balanceC = this.balanceA * trueX + this.balanceB;
    this.balanceGuessX = 1;
    soundManager.playPop();
    this.render();
  },

  // 4. Interactive Trig & Function Grapher (Ages 15-18)
  graphType: "sin",
  graphAmp: 1,
  graphFreq: 1,

  renderFunctionGrapher(container) {
    container.innerHTML = `
      <div class="max-w-xl mx-auto space-y-6 text-center animate-fadeIn">
        <div class="flex items-center justify-between flex-wrap gap-2">
          <h3 class="text-xl font-bold text-slate-800 dark:text-slate-100 flex items-center gap-2">
            <span>📈</span> Wave & Function Explorer (Ages 15–18)
          </h3>
          <div class="flex gap-2">
            <button onclick="MathLab.setGraphType('sin')" class="px-3 py-1 rounded-xl text-xs font-semibold ${this.graphType === 'sin' ? 'bg-fuchsia-600 text-white' : 'bg-slate-200 dark:bg-slate-800'}">y = A·sin(B·x)</button>
            <button onclick="MathLab.setGraphType('quad')" class="px-3 py-1 rounded-xl text-xs font-semibold ${this.graphType === 'quad' ? 'bg-fuchsia-600 text-white' : 'bg-slate-200 dark:bg-slate-800'}">y = A·x²</button>
          </div>
        </div>

        <div class="bg-white dark:bg-slate-900 border border-slate-200 dark:border-slate-800 rounded-3xl p-4 shadow-sm">
          <canvas id="mathGraphCanvas" width="480" height="220" class="w-full h-auto bg-slate-900 rounded-2xl"></canvas>
        </div>

        <div class="grid grid-cols-1 sm:grid-cols-2 gap-4 bg-slate-50 dark:bg-slate-800/50 p-4 rounded-2xl border border-slate-200 dark:border-slate-700 text-left">
          <div>
            <div class="flex justify-between text-xs font-bold text-slate-500 mb-1">
              <span>Amplitude / Scale (A):</span>
              <span class="font-mono text-fuchsia-500">${this.graphAmp}</span>
            </div>
            <input type="range" min="0.5" max="3" step="0.25" value="${this.graphAmp}" oninput="MathLab.setGraphAmp(this.value)" class="w-full accent-fuchsia-500 cursor-pointer" />
          </div>

          <div>
            <div class="flex justify-between text-xs font-bold text-slate-500 mb-1">
              <span>Frequency / Parameter (B):</span>
              <span class="font-mono text-purple-500">${this.graphFreq}</span>
            </div>
            <input type="range" min="0.5" max="3" step="0.25" value="${this.graphFreq}" oninput="MathLab.setGraphFreq(this.value)" class="w-full accent-purple-500 cursor-pointer" />
          </div>
        </div>
      </div>
    `;

    setTimeout(() => this.drawGraphCanvas(), 30);
  },

  setGraphType(type) {
    this.graphType = type;
    this.render();
  },

  setGraphAmp(val) {
    this.graphAmp = parseFloat(val);
    this.drawGraphCanvas();
    const lbl = document.querySelector(".text-fuchsia-500");
    if (lbl) lbl.textContent = this.graphAmp;
  },

  setGraphFreq(val) {
    this.graphFreq = parseFloat(val);
    this.drawGraphCanvas();
    const lbl = document.querySelector(".text-purple-500");
    if (lbl) lbl.textContent = this.graphFreq;
  },

  drawGraphCanvas() {
    const canvas = document.getElementById("mathGraphCanvas");
    if (!canvas) return;
    const ctx = canvas.getContext("2d");
    const w = canvas.width;
    const h = canvas.height;

    // Clear background
    ctx.fillStyle = "#0f172a";
    ctx.fillRect(0, 0, w, h);

    // Draw Grid
    ctx.strokeStyle = "#1e293b";
    ctx.lineWidth = 1;
    for (let x = 0; x < w; x += 30) {
      ctx.beginPath();
      ctx.moveTo(x, 0);
      ctx.lineTo(x, h);
      ctx.stroke();
    }
    for (let y = 0; y < h; y += 30) {
      ctx.beginPath();
      ctx.moveTo(0, y);
      ctx.lineTo(w, y);
      ctx.stroke();
    }

    // Axes
    ctx.strokeStyle = "#475569";
    ctx.lineWidth = 2;
    // X Axis
    ctx.beginPath();
    ctx.moveTo(0, h / 2);
    ctx.lineTo(w, h / 2);
    ctx.stroke();
    // Y Axis
    ctx.beginPath();
    ctx.moveTo(w / 2, 0);
    ctx.lineTo(w / 2, h);
    ctx.stroke();

    // Plot Curve
    ctx.strokeStyle = "#d946ef";
    ctx.lineWidth = 3;
    ctx.beginPath();

    const originX = w / 2;
    const originY = h / 2;
    const scaleX = 40;
    const scaleY = 35;

    let first = true;
    for (let px = 0; px < w; px += 2) {
      const mathX = (px - originX) / scaleX;
      let mathY = 0;

      if (this.graphType === "sin") {
        mathY = this.graphAmp * Math.sin(this.graphFreq * mathX);
      } else {
        mathY = this.graphAmp * (mathX * mathX) * 0.4;
      }

      const py = originY - (mathY * scaleY);
      if (first) {
        ctx.moveTo(px, py);
        first = false;
      } else {
        ctx.lineTo(px, py);
      }
    }
    ctx.stroke();

    // Label
    ctx.fillStyle = "#f8fafc";
    ctx.font = "12px monospace";
    ctx.fillText(this.graphType === "sin" ? `y = ${this.graphAmp}·sin(${this.graphFreq}·x)` : `y = ${this.graphAmp}·x²`, 14, 24);
  }
};
