// Math Odyssey - Comprehensive Adaptive Curriculum & Procedural Question Generator
// 36 Dynamic Math Concepts across 4 Tiers (Ages 5 to 18) with procedural questions, visual representations, hints, and explanations.

const CURRICULUM = {
  tiers: [
    {
      id: "tier1",
      name: "Junior Explorers",
      ageRange: "Ages 5 – 7",
      grade: "Kindergarten – Grade 2",
      icon: "🌱",
      badge: "Sprout Master",
      color: "from-emerald-400 to-teal-500",
      themeClass: "theme-tier1",
      description: "Visual counting, picture math, number bonds, shapes, clocks, coins, and patterns!",
      topics: [
        { id: "t1_counting", title: "Visual Counting", icon: "🍎", desc: "Count objects and find the number" },
        { id: "t1_addition_sub", title: "Picture Addition & Subtraction", icon: "🧸", desc: "Add and take away with fun visuals" },
        { id: "t1_compare", title: "Greater, Less or Equal", icon: "🐊", desc: "Feed the hungry crocodile the bigger number" },
        { id: "t1_patterns", title: "Pattern Detective", icon: "🎨", desc: "Find the missing color or shape" },
        { id: "t1_ten_frame", title: "Make Ten (Number Bonds)", icon: "🔟", desc: "Fill the frames to make 10" },
        { id: "t1_money", title: "Coin Value & Counting", icon: "🪙", desc: "Pennies (1¢), nickels (5¢), and dimes (10¢)" },
        { id: "t1_clock", title: "Telling Time", icon: "⏰", desc: "Read hours and half-hours on clock faces" },
        { id: "t1_shapes", title: "2D & 3D Shape Detective", icon: "🔷", desc: "Identify circles, triangles, cubes, and cones" },
        { id: "t1_even_odd", title: "Odd vs Even Numbers", icon: "👥", desc: "Pair up numbers to see who has a partner" }
      ]
    },
    {
      id: "tier2",
      name: "Math Pioneers",
      ageRange: "Ages 8 – 11",
      grade: "Grades 3 – 5",
      icon: "⚡",
      badge: "Pioneer Champion",
      color: "from-amber-400 to-orange-500",
      themeClass: "theme-tier2",
      description: "Multiplication tables, division quests, pizza fractions, decimals, area, primes, and graphs!",
      topics: [
        { id: "t2_mult_tables", title: "Lightning Multiplication", icon: "✖️", desc: "Fast times tables up to 12x12" },
        { id: "t2_division", title: "Division & Remainders", icon: "➗", desc: "Equal sharing and remainder hunts" },
        { id: "t2_fractions", title: "Fraction Feast", icon: "🍕", desc: "Identify, compare, and simplify fractions" },
        { id: "t2_word_problems", title: "Real-World Quests", icon: "🧭", desc: "Solve time, money, and measurement stories" },
        { id: "t2_pemdas", title: "Order of Operations (PEMDAS)", icon: "🎯", desc: "Brackets, multiply, divide, add, subtract" },
        { id: "t2_decimals", title: "Decimals & Money Math", icon: "🏷️", desc: "Compare and add decimals (tenths and hundredths)" },
        { id: "t2_area_perim", title: "Area & Perimeter", icon: "📐", desc: "Measure rectangles, grids, and boundaries" },
        { id: "t2_factors_primes", title: "Factors & Prime Numbers", icon: "🔢", desc: "Discover prime numbers and factor pairs" },
        { id: "t2_data_charts", title: "Data Charts & Graphs", icon: "📊", desc: "Read and analyze bar charts and tables" }
      ]
    },
    {
      id: "tier3",
      name: "Algebra Challengers",
      ageRange: "Ages 12 – 14",
      grade: "Grades 6 – 8",
      icon: "🚀",
      badge: "Algebra Ace",
      color: "from-blue-500 to-indigo-600",
      themeClass: "theme-tier3",
      description: "Linear equations, negative integers, ratios, powers, Pythagoras, systems, slopes, and statistics!",
      topics: [
        { id: "t3_linear_eq", title: "Linear Equations (Solve for x)", icon: "⚖️", desc: "Balance the scale and find unknown variables" },
        { id: "t3_integers", title: "Negative Numbers & Integers", icon: "❄️", desc: "Master addition, subtraction & multiplication with signs" },
        { id: "t3_ratios_percent", title: "Ratios & Percentages", icon: "🏷️", desc: "Discounts, ratios, taxes, and unit rates" },
        { id: "t3_exponents_roots", title: "Exponents & Square Roots", icon: "📦", desc: "Powers, negative indices, and perfect squares" },
        { id: "t3_geometry_coord", title: "Geometry & Pythagoras", icon: "📐", desc: "Triangles, angles, Pythagorean theorem & slopes" },
        { id: "t3_scientific_notation", title: "Scientific Notation", icon: "🔬", desc: "Express huge and tiny numbers with powers of 10" },
        { id: "t3_slope_intercept", title: "Slope & Linear Graphs (y = mx + b)", icon: "📈", desc: "Calculate rate of change and y-intercepts" },
        { id: "t3_systems_equations", title: "Systems of Equations", icon: "🔗", desc: "Solve two linear equations simultaneously" },
        { id: "t3_statistics", title: "Statistics (Mean, Median, Mode)", icon: "📊", desc: "Analyze data sets, averages, and spreads" }
      ]
    },
    {
      id: "tier4",
      name: "Master Scholars",
      ageRange: "Ages 15 – 18",
      grade: "High School & College Prep",
      icon: "👑",
      badge: "Quantum Genius",
      color: "from-fuchsia-500 to-purple-600",
      themeClass: "theme-tier4",
      description: "Quadratics, trigonometry, logarithms, probability, derivatives, matrices, complex numbers & integrals!",
      topics: [
        { id: "t4_quadratics", title: "Quadratic Equations", icon: "📈", desc: "Factoring, vertex, and the discriminant Δ" },
        { id: "t4_trigonometry", title: "Trigonometry & Unit Circle", icon: "🌀", desc: "Sin, cos, tan, exact values & radians" },
        { id: "t4_functions_logs", title: "Logarithms & Functions", icon: "📜", desc: "Log rules, inverse functions & composition f(g(x))" },
        { id: "t4_probability", title: "Probability & Combinatorics", icon: "🎲", desc: "Permutations P(n,r), combinations C(n,r) & odds" },
        { id: "t4_calculus_limits", title: "Calculus & Derivatives", icon: "∫", desc: "Power rule derivatives, slopes & basic limits" },
        { id: "t4_matrices", title: "Matrices & Determinants", icon: "🧮", desc: "Calculate 2x2 determinants (ad - bc)" },
        { id: "t4_sequences_series", title: "Sequences & Series", icon: "🪜", desc: "Arithmetic & geometric progressions" },
        { id: "t4_complex_numbers", title: "Complex Numbers (i² = -1)", icon: "🔮", desc: "Arithmetic with imaginary and real parts" },
        { id: "t4_integrals", title: "Antiderivatives & Integrals", icon: "∫dx", desc: "Basic power-rule integration and areas" }
      ]
    }
  ]
};

// Utilities for random number generation
function randInt(min, max) {
  return Math.floor(Math.random() * (max - min + 1)) + min;
}

function shuffleArray(arr) {
  const copy = [...arr];
  for (let i = copy.length - 1; i > 0; i--) {
    const j = Math.floor(Math.random() * (i + 1));
    [copy[i], copy[j]] = [copy[j], copy[i]];
  }
  return copy;
}

function makeUniqueOptions(correctVal, distractorGenerator, count = 4, isString = false) {
  const optionsSet = new Set();
  optionsSet.add(correctVal.toString());

  let attempts = 0;
  while (optionsSet.size < count && attempts < 50) {
    attempts++;
    const dist = distractorGenerator();
    if (dist !== undefined && dist !== null) {
      optionsSet.add(dist.toString());
    }
  }

  // Fallback in case generator ran out of variety
  let fallbackDelta = 1;
  while (optionsSet.size < count) {
    if (!isString && !isNaN(Number(correctVal))) {
      const num = Number(correctVal);
      optionsSet.add((num + fallbackDelta).toString());
      if (optionsSet.size < count) optionsSet.add((num - fallbackDelta).toString());
      fallbackDelta++;
    } else {
      optionsSet.add("Option " + (optionsSet.size + 1));
    }
  }

  const finalArr = Array.from(optionsSet);
  return shuffleArray(finalArr).map(val => isString ? val : (isNaN(Number(val)) ? val : (Number.isInteger(Number(val)) ? Number(val) : parseFloat(Number(val).toFixed(2)))));
}

const EMOJI_ITEMS = ["🍎", "⭐", "🎈", "🦆", "🍓", "🧁", "🚀", "🐼", "💎", "🐸"];

// ==========================================
// TIER 1 GENERATOR (Ages 5-7)
// ==========================================
function generateTier1Question(topicId, difficulty = 1) {
  const emoji = EMOJI_ITEMS[randInt(0, EMOJI_ITEMS.length - 1)];

  switch (topicId) {
    case "t1_counting": {
      const count = difficulty === 1 ? randInt(2, 7) : randInt(5, 12);
      const display = Array(count).fill(emoji).join(" ");
      const options = makeUniqueOptions(count, () => Math.max(1, count + randInt(-3, 3)));
      return {
        question: `How many ${emoji} do you count?`,
        visualContent: `<div class="text-3xl sm:text-4xl tracking-widest my-3 p-4 bg-emerald-50 dark:bg-emerald-950/40 rounded-2xl border-2 border-emerald-300 dark:border-emerald-700/60 inline-block shadow-inner">${display}</div>`,
        options,
        correctAnswer: count,
        hint: `Tap and count each ${emoji} one by one with your finger!`,
        explanation: `There are ${count} items in total. Counting: 1, 2, ... up to ${count}!`
      };
    }

    case "t1_addition_sub": {
      const isSub = difficulty > 1 && Math.random() > 0.4;
      if (isSub) {
        const a = randInt(4, 10);
        const b = randInt(1, a - 1);
        const ans = a - b;
        const visual = `<div class="flex items-center justify-center gap-2 flex-wrap text-2xl sm:text-3xl my-2">
          <span class="bg-emerald-100 dark:bg-emerald-900/50 px-3 py-1.5 rounded-xl border border-emerald-300">${Array(a).fill(emoji).join(" ")}</span>
          <span class="font-black text-rose-500 text-3xl">➖</span>
          <span class="bg-rose-100 dark:bg-rose-900/50 px-3 py-1.5 rounded-xl border border-rose-300">${Array(b).fill(emoji).join(" ")}</span>
        </div>`;
        const options = makeUniqueOptions(ans, () => Math.max(0, ans + randInt(-2, 3)));
        return {
          question: `Take away: ${a} − ${b} = ?`,
          visualContent: visual,
          options,
          correctAnswer: ans,
          hint: `You have ${a} items and take away ${b}. How many are left?`,
          explanation: `${a} minus ${b} equals ${ans}. (${a} − ${b} = ${ans})`
        };
      } else {
        const a = randInt(1, 5);
        const b = randInt(1, 5);
        const ans = a + b;
        const visual = `<div class="flex items-center justify-center gap-2 flex-wrap text-2xl sm:text-3xl my-2">
          <span class="bg-emerald-100 dark:bg-emerald-900/50 px-3 py-1.5 rounded-xl border border-emerald-300">${Array(a).fill(emoji).join(" ")}</span>
          <span class="font-black text-emerald-600 text-3xl">➕</span>
          <span class="bg-emerald-100 dark:bg-emerald-900/50 px-3 py-1.5 rounded-xl border border-emerald-300">${Array(b).fill(emoji).join(" ")}</span>
        </div>`;
        const options = makeUniqueOptions(ans, () => Math.max(1, ans + randInt(-3, 3)));
        return {
          question: `Add together: ${a} + ${b} = ?`,
          visualContent: visual,
          options,
          correctAnswer: ans,
          hint: `Count the first group (${a}), then count the second group (${b}) together!`,
          explanation: `${a} + ${b} = ${ans}. When you combine them, you have ${ans} items!`
        };
      }
    }

    case "t1_compare": {
      const a = randInt(1, 15);
      let b = randInt(1, 15);
      while (b === a) b = randInt(1, 15);
      const isGreater = a > b;
      const ans = isGreater ? ">" : "<";
      return {
        question: `Which sign goes in the middle? 🐊 (The crocodile eats the bigger number!)`,
        visualContent: `
          <div class="flex items-center justify-center gap-4 text-3xl font-black my-4">
            <span class="px-5 py-3 rounded-2xl bg-amber-100 dark:bg-amber-900/50 text-amber-700 dark:text-amber-300 border-2 border-amber-400">${a}</span>
            <span class="px-4 py-2 rounded-xl bg-slate-200 dark:bg-slate-700 text-slate-500 text-2xl font-mono">?</span>
            <span class="px-5 py-3 rounded-2xl bg-sky-100 dark:bg-sky-900/50 text-sky-700 dark:text-sky-300 border-2 border-sky-400">${b}</span>
          </div>`,
        options: [">", "<", "="],
        correctAnswer: ans,
        hint: `Which number is bigger: ${a} or ${b}? The mouth opens toward the bigger number!`,
        explanation: `${a} is ${isGreater ? 'greater than' : 'less than'} ${b}, so we write ${a} ${ans} ${b}.`
      };
    }

    case "t1_patterns": {
      const p1 = "🔴", p2 = "⭐", p3 = "🟦";
      const patternTypes = [
        { seq: [p1, p2, p1, p2, p1], next: p2, name: "AB pattern" },
        { seq: [p1, p1, p2, p1, p1], next: p2, name: "AAB pattern" },
        { seq: [p1, p2, p3, p1, p2], next: p3, name: "ABC pattern" }
      ];
      const selected = patternTypes[randInt(0, difficulty === 1 ? 0 : patternTypes.length - 1)];
      const display = selected.seq.join(" ") + " ❓";
      return {
        question: "What comes next in the pattern?",
        visualContent: `<div class="text-3xl tracking-widest my-3 p-4 bg-purple-50 dark:bg-purple-950/40 rounded-2xl border-2 border-purple-300 dark:border-purple-700/60 inline-block">${display}</div>`,
        options: shuffleArray([p1, p2, p3]),
        correctAnswer: selected.next,
        hint: "Say the pattern out loud to hear the rhythm!",
        explanation: `The pattern repeats! The symbol following ${selected.seq[selected.seq.length - 1]} is ${selected.next}.`
      };
    }

    case "t1_ten_frame": {
      const filled = randInt(1, 9);
      const needed = 10 - filled;
      let frameHtml = '<div class="grid grid-cols-5 gap-2 max-w-[240px] mx-auto my-3 p-3 bg-slate-100 dark:bg-slate-800 rounded-2xl border-2 border-slate-300 dark:border-slate-600">';
      for (let i = 0; i < 10; i++) {
        if (i < filled) {
          frameHtml += '<div class="w-9 h-9 sm:w-10 sm:h-10 rounded-full bg-emerald-500 shadow-md flex items-center justify-center text-white font-bold text-sm">●</div>';
        } else {
          frameHtml += '<div class="w-9 h-9 sm:w-10 sm:h-10 rounded-full border-2 border-dashed border-slate-400 dark:border-slate-500 flex items-center justify-center text-slate-400 font-bold text-xs">○</div>';
        }
      }
      frameHtml += '</div>';

      const options = makeUniqueOptions(needed, () => Math.max(1, needed + randInt(-2, 2)));
      return {
        question: `How many more dots to make 10? (${filled} + ❓ = 10)`,
        visualContent: frameHtml,
        options,
        correctAnswer: needed,
        hint: `Count the empty dashed circles ○ in the frame!`,
        explanation: `${filled} plus ${needed} makes 10! Number bond: ${filled} + ${needed} = 10.`
      };
    }

    case "t1_money": {
      const dimes = randInt(1, 3);
      const nickels = randInt(0, 2);
      const pennies = randInt(1, 4);
      const totalCents = (dimes * 10) + (nickels * 5) + (pennies * 1);

      let coinsHtml = `<div class="flex items-center justify-center gap-2 flex-wrap my-3 text-lg font-bold">`;
      for (let i = 0; i < dimes; i++) coinsHtml += `<span class="px-3 py-1.5 bg-blue-100 text-blue-800 rounded-full border border-blue-300">🪙 10¢</span>`;
      for (let i = 0; i < nickels; i++) coinsHtml += `<span class="px-3 py-1.5 bg-amber-100 text-amber-800 rounded-full border border-amber-300">🪙 5¢</span>`;
      for (let i = 0; i < pennies; i++) coinsHtml += `<span class="px-3 py-1.5 bg-rose-100 text-rose-800 rounded-full border border-rose-300">🪙 1¢</span>`;
      coinsHtml += `</div>`;

      const options = makeUniqueOptions(totalCents, () => Math.max(5, totalCents + randInt(-6, 6)));
      return {
        question: `How many cents in total? 🪙`,
        visualContent: coinsHtml,
        options: options.map(o => `${o}¢`),
        correctAnswer: `${totalCents}¢`,
        hint: `Dimes are 10¢, Nickels are 5¢, and Pennies are 1¢. Add them together!`,
        explanation: `${dimes} dime(s) (${dimes*10}¢) + ${nickels} nickel(s) (${nickels*5}¢) + ${pennies} penn(ies) (${pennies}¢) = ${totalCents}¢.`
      };
    }

    case "t1_clock": {
      const hour = randInt(1, 12);
      const isHalf = Math.random() > 0.5;
      const timeStr = isHalf ? `${hour}:30` : `${hour}:00`;
      const desc = isHalf ? `Short hour hand between ${hour} and ${hour === 12 ? 1 : hour + 1}, long minute hand on 6` : `Short hour hand on ${hour}, long minute hand pointing straight up to 12`;

      const options = makeUniqueOptions(timeStr, () => {
        const h = randInt(1, 12);
        return Math.random() > 0.5 ? `${h}:30` : `${h}:00`;
      }, 4, true);

      return {
        question: `What time does this clock show?`,
        visualContent: `
          <div class="my-3 p-4 bg-sky-50 dark:bg-sky-950/40 border-2 border-sky-300 rounded-2xl max-w-xs mx-auto text-center font-bold text-slate-800 dark:text-slate-100">
            <div class="text-4xl mb-1">⏰</div>
            <div class="text-sm text-slate-600 dark:text-slate-300">${desc}</div>
          </div>`,
        options,
        correctAnswer: timeStr,
        hint: `When the long hand is on 12, it is ":00" o'clock. When on 6, it is ":30"!`,
        explanation: `The short hand shows the hour (${hour}) and the long hand indicates ${isHalf ? 'half-past (:30)' : "o'clock (:00)"}. Time is ${timeStr}.`
      };
    }

    case "t1_shapes": {
      const shapeQuestions = [
        { q: "How many corners (vertices) does a Triangle have?", icon: "🔺", ans: 3, expl: "A triangle always has 3 sides and 3 corners!" },
        { q: "How many sides does a Rectangle have?", icon: "🟦", ans: 4, expl: "A rectangle has 4 straight sides." },
        { q: "How many faces does a 3D Cube have?", icon: "🎲", ans: 6, expl: "A cube has 6 square faces (like a gaming die with numbers 1 to 6)!" },
        { q: "Which 3D shape is shaped like a round ball?", icon: "⚽", ans: "Sphere", isStr: true, bank: ["Cube", "Cylinder", "Cone", "Sphere"], expl: "A round 3D ball is called a Sphere." }
      ];
      const sq = shapeQuestions[randInt(0, shapeQuestions.length - 1)];

      if (sq.isStr) {
        return {
          question: sq.q,
          visualContent: `<div class="text-5xl my-2">${sq.icon}</div>`,
          options: shuffleArray(sq.bank),
          correctAnswer: sq.ans,
          hint: "Think about soccer balls and planets!",
          explanation: sq.expl
        };
      } else {
        const options = makeUniqueOptions(sq.ans, () => Math.max(1, sq.ans + randInt(-2, 2)));
        return {
          question: sq.q,
          visualContent: `<div class="text-5xl my-2">${sq.icon}</div>`,
          options,
          correctAnswer: sq.ans,
          hint: "Count the sides or corners carefully!",
          explanation: sq.expl
        };
      }
    }

    case "t1_even_odd": {
      const num = randInt(2, 12);
      const isEven = num % 2 === 0;
      let dotsHtml = `<div class="flex justify-center gap-1.5 flex-wrap my-3">`;
      for (let i = 0; i < Math.floor(num / 2); i++) {
        dotsHtml += `<span class="px-2 py-1 bg-emerald-100 dark:bg-emerald-900 border border-emerald-400 rounded-lg text-lg">●●</span>`;
      }
      if (num % 2 !== 0) {
        dotsHtml += `<span class="px-2 py-1 bg-rose-100 dark:bg-rose-900 border border-rose-400 rounded-lg text-lg">●</span>`;
      }
      dotsHtml += `</div>`;

      return {
        question: `Is the number ${num} Even or Odd?`,
        visualContent: `${dotsHtml}<div class="text-xs text-slate-500 font-bold">${isEven ? "Everyone has a partner pair! 👥" : "One dot is left alone without a partner! 👤"}</div>`,
        options: ["Even", "Odd"],
        correctAnswer: isEven ? "Even" : "Odd",
        hint: `Can ${num} be split equally between 2 friends with nothing leftover?`,
        explanation: `${num} is ${isEven ? 'EVEN because it pairs up completely' : 'ODD because 1 is leftover'}.`
      };
    }

    default:
      return generateTier1Question("t1_counting", difficulty);
  }
}

// ==========================================
// TIER 2 GENERATOR (Ages 8-11)
// ==========================================
function generateTier2Question(topicId, difficulty = 1) {
  switch (topicId) {
    case "t2_mult_tables": {
      const a = randInt(2, 12);
      const b = randInt(difficulty === 1 ? 2 : 5, 12);
      const ans = a * b;
      if (Math.random() > 0.7) {
        const options = makeUniqueOptions(b, () => Math.max(1, b + randInt(-3, 3)));
        return {
          question: `Find the missing factor: ${a} × ❓ = ${ans}`,
          visualContent: `<div class="text-3xl font-black text-amber-500 my-2">${a} × ❓ = ${ans}</div>`,
          options,
          correctAnswer: b,
          hint: `Think: What number multiplied by ${a} gives ${ans}?`,
          explanation: `Since ${ans} ÷ ${a} = ${b}, the missing number is ${b}.`
        };
      } else {
        const options = makeUniqueOptions(ans, () => Math.max(1, ans + (randInt(-3, 3) * a || randInt(1, 5))));
        return {
          question: `Calculate: ${a} × ${b} = ?`,
          visualContent: `<div class="text-4xl font-extrabold text-amber-500 my-2">${a} × ${b}</div>`,
          options,
          correctAnswer: ans,
          hint: `${a} groups of ${b}. You can also think of it as ${b} × ${a}.`,
          explanation: `${a} × ${b} = ${ans}.`
        };
      }
    }

    case "t2_division": {
      const divisor = randInt(2, 10);
      const quotient = randInt(2, 11);
      const hasRemainder = difficulty > 1 && Math.random() > 0.5;
      const remainder = hasRemainder ? randInt(1, divisor - 1) : 0;
      const dividend = divisor * quotient + remainder;

      if (!hasRemainder) {
        const options = makeUniqueOptions(quotient, () => Math.max(1, quotient + randInt(-3, 3)));
        return {
          question: `Calculate: ${dividend} ÷ ${divisor} = ?`,
          visualContent: `<div class="text-4xl font-extrabold text-orange-500 my-2">${dividend} ÷ ${divisor}</div>`,
          options,
          correctAnswer: quotient,
          hint: `What times ${divisor} gives ${dividend}?`,
          explanation: `${dividend} ÷ ${divisor} = ${quotient} because ${quotient} × ${divisor} = ${dividend}.`
        };
      } else {
        const correctStr = `${quotient} R ${remainder}`;
        const options = makeUniqueOptions(correctStr, () => {
          const q = Math.max(1, quotient + randInt(-2, 2));
          const r = Math.max(1, randInt(1, divisor - 1));
          return `${q} R ${r}`;
        }, 4, true);
        return {
          question: `Find quotient & remainder: ${dividend} ÷ ${divisor} = ?`,
          visualContent: `<div class="text-3xl font-extrabold text-orange-500 my-2">${dividend} ÷ ${divisor}</div>`,
          options,
          correctAnswer: correctStr,
          hint: `${divisor} goes into ${dividend} how many whole times, and what is leftover?`,
          explanation: `${divisor} × ${quotient} = ${divisor * quotient}. Leftover: ${dividend} − ${divisor * quotient} = ${remainder}. Answer: ${quotient} R ${remainder}.`
        };
      }
    }

    case "t2_fractions": {
      const types = ["compare", "addition", "simplify"];
      const type = types[randInt(0, types.length - 1)];

      if (type === "addition") {
        const denom = randInt(3, 8);
        const num1 = randInt(1, denom - 2);
        const num2 = randInt(1, denom - num1);
        const sumNum = num1 + num2;
        const correctStr = `${sumNum}/${denom}`;

        const options = makeUniqueOptions(correctStr, () => `${Math.max(1, sumNum + randInt(-2, 2))}/${denom}`, 4, true);

        return {
          question: `Add the fractions with like denominators:`,
          visualContent: `<div class="text-3xl font-bold text-amber-500 my-3 flex items-center justify-center gap-2">
            <span>${num1}/${denom}</span> <span>+</span> <span>${num2}/${denom}</span> <span>=</span> <span>?</span>
          </div>`,
          options,
          correctAnswer: correctStr,
          hint: `Keep denominator the same and add the numerators!`,
          explanation: `${num1}/${denom} + ${num2}/${denom} = (${num1} + ${num2})/${denom} = ${sumNum}/${denom}.`
        };
      } else if (type === "simplify") {
        const factor = randInt(2, 4);
        const baseNum = randInt(1, 3);
        const baseDenom = baseNum + randInt(1, 4);
        const origNum = baseNum * factor;
        const origDenom = baseDenom * factor;
        const correctStr = `${baseNum}/${baseDenom}`;

        const options = makeUniqueOptions(correctStr, () => `${randInt(1, 4)}/${randInt(3, 7)}`, 4, true);

        return {
          question: `Simplify this fraction to simplest form:`,
          visualContent: `<div class="text-4xl font-bold text-amber-500 my-3">${origNum}/${origDenom}</div>`,
          options,
          correctAnswer: correctStr,
          hint: `Divide both top and bottom by ${factor}!`,
          explanation: `${origNum} ÷ ${factor} = ${baseNum}, ${origDenom} ÷ ${factor} = ${baseDenom}. Result: ${baseNum}/${baseDenom}.`
        };
      } else {
        const denom = randInt(4, 10);
        const n1 = randInt(1, denom - 2);
        const n2 = randInt(n1 + 1, denom);
        return {
          question: `Compare fractions: Which sign makes it true?`,
          visualContent: `<div class="text-3xl font-bold text-amber-600 my-3 flex items-center justify-center gap-4">
            <span>${n1}/${denom}</span> <span class="px-3 py-1 bg-slate-200 dark:bg-slate-700 rounded-lg">?</span> <span>${n2}/${denom}</span>
          </div>`,
          options: ["<", ">", "="],
          correctAnswer: "<",
          hint: `Since both denominators are ${denom}, compare top numbers ${n1} and ${n2}.`,
          explanation: `${n1} < ${n2}, therefore ${n1}/${denom} < ${n2}/${denom}.`
        };
      }
    }

    case "t2_word_problems": {
      const problems = [
        { q: "Maya had $35. She bought a book for $14 and stickers for $6. How much money is left?", ans: 15, expl: "Spent: $14 + $6 = $20. Remaining: $35 - $20 = $15." },
        { q: "A bakery baked 48 cupcakes and packed them equally into 6 boxes. How many per box?", ans: 8, expl: "48 ÷ 6 = 8 cupcakes per box." },
        { q: "Liam started reading at 4:15 PM and finished at 5:00 PM. How many minutes?", ans: 45, expl: "From 4:15 PM to 5:00 PM is 45 minutes." },
        { q: "A garden has 7 rows of tomato plants. Each row has 9 plants. Total plants?", ans: 63, expl: "7 rows × 9 plants = 63 plants." }
      ];
      const p = problems[randInt(0, problems.length - 1)];
      const options = makeUniqueOptions(p.ans, () => Math.max(1, p.ans + randInt(-8, 8)));
      return {
        question: p.q,
        visualContent: `<div class="p-3 bg-amber-50 dark:bg-amber-950/40 border border-amber-200 rounded-xl my-2 text-base font-medium">📖 Story Quest</div>`,
        options,
        correctAnswer: p.ans,
        hint: "Break the problem down into parts!",
        explanation: p.expl
      };
    }

    case "t2_pemdas": {
      const a = randInt(2, 6);
      const b = randInt(2, 5);
      const c = randInt(2, 6);
      const isBrackets = difficulty > 1 && Math.random() > 0.5;
      if (isBrackets) {
        const ans = (a + b) * c;
        const options = makeUniqueOptions(ans, () => a + (b * c) + randInt(-4, 4));
        return {
          question: `Evaluate using PEMDAS:`,
          visualContent: `<div class="text-3xl font-black text-amber-500 my-2">(${a} + ${b}) × ${c}</div>`,
          options,
          correctAnswer: ans,
          hint: `Parentheses first! (${a} + ${b})`,
          explanation: `1. (${a} + ${b}) = ${a + b}. 2. ${a + b} × ${c} = ${ans}.`
        };
      } else {
        const ans = a + b * c;
        const options = makeUniqueOptions(ans, () => Math.random() > 0.5 ? (a+b)*c : ans + randInt(-5, 5));
        return {
          question: `Evaluate using order of operations:`,
          visualContent: `<div class="text-3xl font-black text-amber-500 my-2">${a} + ${b} × ${c}</div>`,
          options,
          correctAnswer: ans,
          hint: `Multiplication comes before Addition in PEMDAS!`,
          explanation: `1. ${b} × ${c} = ${b * c}. 2. ${a} + ${b * c} = ${ans}.`
        };
      }
    }

    case "t2_decimals": {
      const a = (randInt(10, 50) / 10);
      const b = (randInt(5, 35) / 10);
      const sum = parseFloat((a + b).toFixed(1));
      const options = makeUniqueOptions(sum, () => parseFloat((sum + randInt(-3, 3) * 0.5).toFixed(1)));
      return {
        question: `Add the decimal numbers:`,
        visualContent: `<div class="text-3xl font-bold text-amber-500 my-2">${a} + ${b} = ?</div>`,
        options,
        correctAnswer: sum,
        hint: `Line up the decimal points and add just like whole numbers!`,
        explanation: `${a} + ${b} = ${sum}.`
      };
    }

    case "t2_area_perim": {
      const length = randInt(4, 9);
      const width = randInt(2, 6);
      const isArea = Math.random() > 0.5;
      const ans = isArea ? (length * width) : (2 * (length + width));

      const options = makeUniqueOptions(ans, () => Math.max(4, ans + randInt(-6, 6)));
      return {
        question: `Rectangle with Length = ${length} cm and Width = ${width} cm. Find its ${isArea ? 'Area (cm²)' : 'Perimeter (cm)'}:`,
        visualContent: `
          <div class="my-3 p-4 bg-amber-50 dark:bg-amber-950/40 border-2 border-amber-300 rounded-2xl max-w-xs mx-auto text-center font-bold">
            <div class="border-2 border-dashed border-amber-500 py-6 px-10 rounded-lg inline-block text-sm">
              <div>Top: ${length} cm</div>
              <div class="text-amber-600 font-extrabold text-base my-1">${isArea ? 'Area = L × W' : 'Perimeter = 2×(L+W)'}</div>
              <div>Side: ${width} cm</div>
            </div>
          </div>`,
        options,
        correctAnswer: ans,
        hint: isArea ? `Area = Length × Width (${length} × ${width})` : `Perimeter = 2 × (Length + Width) = 2 × (${length} + ${width})`,
        explanation: isArea ? `Area = ${length} × ${width} = ${ans} cm²` : `Perimeter = 2 × (${length} + ${width}) = ${ans} cm`
      };
    }

    case "t2_factors_primes": {
      const primes = [2, 3, 5, 7, 11, 13, 17, 19, 23];
      const composites = [4, 6, 8, 9, 10, 12, 14, 15, 16, 18, 20];
      const p = primes[randInt(0, primes.length - 1)];
      const compChoices = shuffleArray(composites).slice(0, 3);
      const options = shuffleArray([p, ...compChoices]);

      return {
        question: `Which of the following numbers is a Prime Number? (Only divisible by 1 and itself)`,
        visualContent: `<div class="text-2xl font-bold text-amber-500 my-2">Prime Hunter 🔢</div>`,
        options,
        correctAnswer: p,
        hint: `A prime number has exactly two factors: 1 and itself!`,
        explanation: `${p} is a prime number because its only factors are 1 and ${p}.`
      };
    }

    case "t2_data_charts": {
      const cats = randInt(4, 10);
      const dogs = cats + randInt(2, 6);
      const birds = randInt(2, 5);
      const diff = dogs - cats;

      const options = makeUniqueOptions(diff, () => Math.max(1, diff + randInt(-3, 3)));
      return {
        question: `Based on the pet survey: How many MORE people chose Dogs than Cats?`,
        visualContent: `
          <div class="space-y-2 p-3 bg-slate-100 dark:bg-slate-800 rounded-2xl max-w-xs mx-auto text-left text-xs font-bold">
            <div>🐕 Dogs: <span class="text-blue-500 font-mono">${dogs}</span></div>
            <div>🐈 Cats: <span class="text-amber-500 font-mono">${cats}</span></div>
            <div>🦜 Birds: <span class="text-emerald-500 font-mono">${birds}</span></div>
          </div>`,
        options,
        correctAnswer: diff,
        hint: `Subtract the number of Cats (${cats}) from Dogs (${dogs})!`,
        explanation: `Dogs (${dogs}) − Cats (${cats}) = ${diff} more people.`
      };
    }

    default:
      return generateTier2Question("t2_mult_tables", difficulty);
  }
}

// ==========================================
// TIER 3 GENERATOR (Ages 12-14)
// ==========================================
function generateTier3Question(topicId, difficulty = 1) {
  switch (topicId) {
    case "t3_linear_eq": {
      const a = randInt(2, 6);
      const x = randInt(2, 9);
      const b = randInt(1, 15);
      const isMinus = Math.random() > 0.5;
      const c = isMinus ? (a * x - b) : (a * x + b);
      const eqStr = isMinus ? `${a}x − ${b} = ${c}` : `${a}x + ${b} = ${c}`;

      const options = makeUniqueOptions(x, () => Math.max(1, x + randInt(-3, 3)));
      return {
        question: `Solve for x:`,
        visualContent: `<div class="text-3xl font-mono font-bold text-blue-500 my-2">${eqStr}</div>`,
        options,
        correctAnswer: x,
        hint: isMinus ? `Add ${b} to both sides, then divide by ${a}.` : `Subtract ${b} from both sides, then divide by ${a}.`,
        explanation: isMinus
          ? `1. ${a}x = ${c} + ${b} = ${c + b}\n2. x = ${c + b} ÷ ${a} = ${x}`
          : `1. ${a}x = ${c} − ${b} = ${c - b}\n2. x = ${c - b} ÷ ${a} = ${x}`
      };
    }

    case "t3_integers": {
      const a = randInt(-15, 15);
      const b = randInt(-15, 15);
      const ops = ["+", "−", "×"];
      const op = ops[randInt(0, ops.length - 1)];

      let ans;
      let expr;
      if (op === "+") {
        ans = a + b;
        expr = `(${a}) + (${b})`;
      } else if (op === "−") {
        ans = a - b;
        expr = `(${a}) − (${b})`;
      } else {
        const smallA = randInt(-8, 8);
        const smallB = randInt(-8, 8);
        ans = smallA * smallB;
        expr = `(${smallA}) × (${smallB})`;
      }

      const options = makeUniqueOptions(ans, () => ans + randInt(-6, 6));
      return {
        question: `Calculate with negative integers:`,
        visualContent: `<div class="text-3xl font-mono font-bold text-indigo-500 my-2">${expr}</div>`,
        options,
        correctAnswer: ans,
        hint: "Remember sign rules: minus of a negative becomes positive! Neg × Neg = Pos.",
        explanation: `Result of ${expr} = ${ans}.`
      };
    }

    case "t3_ratios_percent": {
      const types = ["percent_of", "discount", "ratio"];
      const t = types[randInt(0, types.length - 1)];

      if (t === "percent_of") {
        const percent = [10, 15, 20, 25, 50, 75][randInt(0, 5)];
        const whole = randInt(2, 10) * (percent === 15 ? 20 : (100 / (percent === 75 ? 25 : (percent === 25 ? 25 : 10))));
        const ans = (percent / 100) * whole;
        const options = makeUniqueOptions(ans, () => Math.max(1, ans + randInt(-10, 10)));
        return {
          question: `What is ${percent}% of ${whole}?`,
          visualContent: `<div class="text-3xl font-bold text-blue-500 my-2">${percent}% of ${whole}</div>`,
          options,
          correctAnswer: ans,
          hint: `${percent}% = ${percent}/100 = ${(percent / 100).toFixed(2)}. Multiply by ${whole}.`,
          explanation: `(${percent} ÷ 100) × ${whole} = ${ans}.`
        };
      } else if (t === "discount") {
        const price = [40, 50, 60, 80, 100, 120][randInt(0, 5)];
        const disc = [10, 20, 25, 30, 50][randInt(0, 4)];
        const ans = price - (price * disc / 100);
        const options = makeUniqueOptions(ans, () => Math.max(10, ans + randInt(-15, 15)));
        return {
          question: `A jacket costs $${price}. A ${disc}% discount applies. What is the sale price?`,
          visualContent: `<div class="text-2xl font-bold text-indigo-500 my-2">$${price} with ${disc}% OFF</div>`,
          options,
          correctAnswer: ans,
          hint: `Discount amount = ${disc}% of $${price}. Subtract that from $${price}.`,
          explanation: `Discount = $${price * disc / 100}. Final price = $${price} − $${price * disc / 100} = $${ans}.`
        };
      } else {
        const r1 = randInt(2, 5);
        const r2 = randInt(2, 5);
        const multiplier = randInt(3, 8);
        const part1 = r1 * multiplier;
        const part2 = r2 * multiplier;
        const options = makeUniqueOptions(part2, () => Math.max(1, part2 + randInt(-6, 6)));
        return {
          question: `The ratio of red to blue marbles is ${r1} : ${r2}. If there are ${part1} red marbles, how many blue marbles are there?`,
          visualContent: `<div class="text-2xl font-bold text-blue-500 my-2">Ratio: ${r1} : ${r2} | Red: ${part1} | Blue: ❓</div>`,
          options,
          correctAnswer: part2,
          hint: `Find what ${r1} was multiplied by to get ${part1} (${part1} ÷ ${r1}), then multiply ${r2} by that factor.`,
          explanation: `Scale factor = ${part1} ÷ ${r1} = ${multiplier}. Blue marbles = ${r2} × ${multiplier} = ${part2}.`
        };
      }
    }

    case "t3_exponents_roots": {
      const isSqrt = Math.random() > 0.5;
      if (isSqrt) {
        const roots = [4, 5, 6, 7, 8, 9, 10, 11, 12, 13, 14, 15];
        const root = roots[randInt(0, roots.length - 1)];
        const sq = root * root;
        const options = makeUniqueOptions(root, () => Math.max(1, root + randInt(-3, 3)));
        return {
          question: `Evaluate the square root:`,
          visualContent: `<div class="text-4xl font-mono font-bold text-blue-500 my-2">√${sq}</div>`,
          options,
          correctAnswer: root,
          hint: `What positive number multiplied by itself equals ${sq}?`,
          explanation: `Since ${root} × ${root} = ${sq}, √${sq} = ${root}.`
        };
      } else {
        const bases = [2, 3, 4, 5, 10];
        const base = bases[randInt(0, bases.length - 1)];
        const exp = base === 2 ? randInt(3, 6) : (base === 3 ? randInt(2, 4) : randInt(2, 3));
        const ans = Math.pow(base, exp);
        const options = makeUniqueOptions(ans, () => Math.max(2, ans + randInt(-15, 15)));
        return {
          question: `Evaluate the power:`,
          visualContent: `<div class="text-4xl font-mono font-bold text-indigo-500 my-2">${base}<sup>${exp}</sup></div>`,
          options,
          correctAnswer: ans,
          hint: `Multiply ${base} by itself ${exp} times!`,
          explanation: `${base}<sup>${exp}</sup> = ${ans}.`
        };
      }
    }

    case "t3_geometry_coord": {
      const triples = [
        { a: 3, b: 4, c: 5 },
        { a: 6, b: 8, c: 10 },
        { a: 5, b: 12, c: 13 },
        { a: 9, b: 12, c: 15 }
      ];
      const trip = triples[randInt(0, triples.length - 1)];
      const findHypotenuse = Math.random() > 0.4;

      if (findHypotenuse) {
        const options = makeUniqueOptions(trip.c, () => Math.max(1, trip.c + randInt(-4, 4)));
        return {
          question: `In a right triangle with legs a = ${trip.a} and b = ${trip.b}, find hypotenuse c:`,
          visualContent: `<div class="text-2xl font-mono font-bold text-blue-600 my-2">c² = ${trip.a}² + ${trip.b}²</div>`,
          options,
          correctAnswer: trip.c,
          hint: `Pythagorean Theorem: a² + b² = c²`,
          explanation: `${trip.a}² + ${trip.b}² = ${trip.a*trip.a + trip.b*trip.b}. √${trip.c*trip.c} = ${trip.c}.`
        };
      } else {
        const options = makeUniqueOptions(trip.b, () => Math.max(1, trip.b + randInt(-4, 4)));
        return {
          question: `In a right triangle, leg a = ${trip.a} and hypotenuse c = ${trip.c}. Find leg b:`,
          visualContent: `<div class="text-2xl font-mono font-bold text-blue-600 my-2">${trip.a}² + b² = ${trip.c}²</div>`,
          options,
          correctAnswer: trip.b,
          hint: `b² = c² − a²`,
          explanation: `b² = ${trip.c}² − ${trip.a}² = ${trip.b*trip.b}. √${trip.b*trip.b} = ${trip.b}.`
        };
      }
    }

    case "t3_scientific_notation": {
      const coeff = randInt(2, 9);
      const exp = randInt(3, 5);
      const standardVal = coeff * Math.pow(10, exp);
      const sciStr = `${coeff} × 10<sup>${exp}</sup>`;

      const options = makeUniqueOptions(standardVal, () => coeff * Math.pow(10, randInt(2, 6)));
      return {
        question: `Convert from scientific notation to standard form:`,
        visualContent: `<div class="text-3xl font-mono font-bold text-blue-500 my-2">${sciStr}</div>`,
        options,
        correctAnswer: standardVal,
        hint: `Move the decimal point ${exp} places to the right (add ${exp} zeros)!`,
        explanation: `${coeff} × 10^${exp} = ${standardVal}.`
      };
    }

    case "t3_slope_intercept": {
      const m = randInt(2, 5);
      const b = randInt(1, 9);
      const options = makeUniqueOptions(m, () => Math.max(1, m + randInt(-3, 3)));
      return {
        question: `Find the slope (m) of the linear equation:`,
        visualContent: `<div class="text-3xl font-mono font-bold text-indigo-500 my-2">y = ${m}x + ${b}</div>`,
        options,
        correctAnswer: m,
        hint: `In slope-intercept form y = mx + b, m is the coefficient in front of x!`,
        explanation: `Comparing to y = mx + b, slope m = ${m} and y-intercept = ${b}.`
      };
    }

    case "t3_systems_equations": {
      const x = randInt(2, 7);
      const y = randInt(1, 5);
      const sum = x + y;
      const diff = x - y;

      const options = makeUniqueOptions(x, () => Math.max(1, x + randInt(-3, 3)));
      return {
        question: `Solve the system of equations for x:`,
        visualContent: `
          <div class="my-2 p-3 bg-blue-50 dark:bg-blue-950/40 rounded-xl font-mono text-xl font-bold text-blue-600">
            <div>x + y = ${sum}</div>
            <div>x − y = ${diff}</div>
          </div>`,
        options,
        correctAnswer: x,
        hint: `Add both equations together: (x + y) + (x - y) = 2x = ${sum + diff}`,
        explanation: `Add the two equations: 2x = ${sum + diff} => x = ${(sum + diff)/2} = ${x}.`
      };
    }

    case "t3_statistics": {
      const n1 = randInt(2, 5);
      const n2 = randInt(4, 7);
      const n3 = n2; // mode
      const n4 = randInt(8, 12);
      const arr = [n1, n2, n3, n4].sort((a,b)=>a-b);
      const range = arr[3] - arr[0];

      const options = makeUniqueOptions(range, () => Math.max(1, range + randInt(-4, 4)));
      return {
        question: `Find the Range of this data set: [${arr.join(", ")}]`,
        visualContent: `<div class="text-2xl font-mono font-bold text-blue-500 my-2">Range = Max − Min</div>`,
        options,
        correctAnswer: range,
        hint: `Range is the difference between maximum (${arr[3]}) and minimum (${arr[0]}) values!`,
        explanation: `Range = ${arr[3]} − ${arr[0]} = ${range}.`
      };
    }

    default:
      return generateTier3Question("t3_linear_eq", difficulty);
  }
}

// ==========================================
// TIER 4 GENERATOR (Ages 15-18)
// ==========================================
function generateTier4Question(topicId, difficulty = 1) {
  switch (topicId) {
    case "t4_quadratics": {
      const r1 = randInt(1, 6);
      const r2 = randInt(-4, 5);
      const b = -(r1 + r2);
      const c = r1 * r2;
      const bSign = b >= 0 ? `+ ${b}x` : `− ${Math.abs(b)}x`;
      const cSign = c >= 0 ? `+ ${c}` : `− ${Math.abs(c)}`;
      const eq = `x² ${bSign} ${cSign} = 0`;

      const correctAns = `x = ${r1}, ${r2}`;
      const options = makeUniqueOptions(correctAns, () => `x = ${r1 + randInt(-2, 2)}, ${r2 + randInt(-2, 2)}`, 4, true);

      return {
        question: `Find the roots of the quadratic equation:`,
        visualContent: `<div class="text-3xl font-mono font-bold text-fuchsia-500 my-2">${eq}</div>`,
        options,
        correctAnswer: correctAns,
        hint: `Factor into (x − r₁)(x − r₂) = 0`,
        explanation: `Factoring: (x − ${r1})(x − ${r2}) = 0. Roots are ${correctAns}.`
      };
    }

    case "t4_trigonometry": {
      const trigValues = [
        { q: "sin(30°)", ans: "1/2", expl: "On the 30-60-90 special right triangle, opposite/hypotenuse = 1/2." },
        { q: "cos(60°)", ans: "1/2", expl: "cos(60°) = adjacent/hypotenuse = 1/2." },
        { q: "sin(90°)", ans: "1", expl: "At π/2 radians (90°), y-coordinate on the unit circle is 1." },
        { q: "cos(0°)", ans: "1", expl: "At 0 radians, x-coordinate on the unit circle is 1." },
        { q: "tan(45°)", ans: "1", expl: "tan(45°) = sin(45°)/cos(45°) = 1." },
        { q: "cos(180°)", ans: "-1", expl: "cos(180°) = -1." },
        { q: "sin(45°)", ans: "√2/2", expl: "sin(45°) = 1/√2 = √2/2." }
      ];
      const selected = trigValues[randInt(0, trigValues.length - 1)];
      const options = makeUniqueOptions(selected.ans, () => ["0", "1/2", "√2/2", "√3/2", "1", "-1"][randInt(0, 5)], 4, true);

      return {
        question: `Find the exact trigonometric value:`,
        visualContent: `<div class="text-4xl font-mono font-bold text-purple-500 my-2">${selected.q}</div>`,
        options,
        correctAnswer: selected.ans,
        hint: `Use unit circle coordinates (cos θ, sin θ) or special right triangles.`,
        explanation: selected.expl
      };
    }

    case "t4_functions_logs": {
      const bases = [2, 3, 5, 10];
      const base = bases[randInt(0, bases.length - 1)];
      const power = randInt(2, 4);
      const arg = Math.pow(base, power);

      const options = makeUniqueOptions(power, () => Math.max(1, power + randInt(-2, 2)));
      return {
        question: `Evaluate the logarithm:`,
        visualContent: `<div class="text-3xl font-mono font-bold text-fuchsia-500 my-2">log<sub>${base}</sub>(${arg})</div>`,
        options,
        correctAnswer: power,
        hint: `Ask: "${base} raised to what power equals ${arg}?"`,
        explanation: `Since ${base}<sup>${power}</sup> = ${arg}, log<sub>${base}</sub>(${arg}) = ${power}.`
      };
    }

    case "t4_probability": {
      const n = randInt(4, 7);
      const ans = (n * (n - 1)) / 2;
      const options = makeUniqueOptions(ans, () => Math.max(1, ans + randInt(-5, 5)));
      return {
        question: `Calculate combinations C(${n}, 2) — choose 2 from ${n} items:`,
        visualContent: `<div class="text-3xl font-mono font-bold text-fuchsia-500 my-2">C(${n}, 2) = <sub>${n}</sub>C<sub>2</sub></div>`,
        options,
        correctAnswer: ans,
        hint: `Formula: C(n, 2) = (n × (n-1)) / 2`,
        explanation: `C(${n}, 2) = (${n} × ${n - 1}) / 2 = ${ans}.`
      };
    }

    case "t4_calculus_limits": {
      const a = randInt(2, 5);
      const n = 3;
      const derivCoeff = a * n;
      const derivAns = `${derivCoeff}x²`;
      const options = makeUniqueOptions(derivAns, () => `${(a + randInt(1, 4)) * n}x²`, 4, true);

      return {
        question: `Find the derivative d/dx of f(x) = ${a}x³:`,
        visualContent: `<div class="text-3xl font-mono font-bold text-fuchsia-500 my-2">d/dx [${a}x³]</div>`,
        options,
        correctAnswer: derivAns,
        hint: `Power rule: d/dx(a·xⁿ) = a·n·xⁿ⁻¹`,
        explanation: `${a} × 3 = ${derivCoeff}, exponent decreases by 1 to 2. Derivative is ${derivAns}.`
      };
    }

    case "t4_matrices": {
      const a = randInt(1, 5);
      const b = randInt(1, 4);
      const c = randInt(1, 4);
      const d = randInt(1, 5);
      const det = (a * d) - (b * c);

      const options = makeUniqueOptions(det, () => det + randInt(-6, 6));
      return {
        question: `Find the determinant of the 2×2 matrix:`,
        visualContent: `
          <div class="my-3 font-mono text-2xl font-bold text-fuchsia-500 inline-block border-x-2 border-fuchsia-400 px-4 py-2">
            <div>${a} &nbsp; ${b}</div>
            <div>${c} &nbsp; ${d}</div>
          </div>`,
        options,
        correctAnswer: det,
        hint: `Formula for determinant of [a b; c d] is: ad − bc!`,
        explanation: `det = (${a} × ${d}) − (${b} × ${c}) = ${a * d} − ${b * c} = ${det}.`
      };
    }

    case "t4_sequences_series": {
      const a1 = randInt(2, 6);
      const d = randInt(2, 5);
      const n = randInt(5, 8);
      const an = a1 + (n - 1) * d;

      const options = makeUniqueOptions(an, () => Math.max(1, an + randInt(-6, 6)));
      return {
        question: `In an arithmetic sequence with first term a₁ = ${a1} and common difference d = ${d}, find term a<sub>${n}</sub>:`,
        visualContent: `<div class="text-2xl font-mono font-bold text-purple-500 my-2">a<sub>n</sub> = a₁ + (n − 1)d</div>`,
        options,
        correctAnswer: an,
        hint: `Formula: aₙ = a₁ + (${n} − 1) × d`,
        explanation: `a<sub>${n}</sub> = ${a1} + (${n - 1} × ${d}) = ${a1} + ${(n - 1) * d} = ${an}.`
      };
    }

    case "t4_complex_numbers": {
      const r1 = randInt(2, 6);
      const i1 = randInt(2, 5);
      const r2 = randInt(1, 4);
      const i2 = randInt(1, 4);
      const resR = r1 + r2;
      const resI = i1 + i2;
      const ansStr = `${resR} + ${resI}i`;

      const options = makeUniqueOptions(ansStr, () => `${resR + randInt(-2, 2)} + ${resI + randInt(-2, 2)}i`, 4, true);
      return {
        question: `Add the complex numbers: (${r1} + ${i1}i) + (${r2} + ${i2}i)`,
        visualContent: `<div class="text-3xl font-mono font-bold text-fuchsia-500 my-2">(${r1} + ${i1}i) + (${r2} + ${i2}i)</div>`,
        options,
        correctAnswer: ansStr,
        hint: `Add the real parts together, and add the imaginary parts together!`,
        explanation: `Real: ${r1} + ${r2} = ${resR}. Imaginary: ${i1}i + ${i2}i = ${resI}i. Sum: ${ansStr}.`
      };
    }

    case "t4_integrals": {
      const a = randInt(2, 6);
      const integCoeff = a / 2;
      const isInteger = Number.isInteger(integCoeff);
      const ans = isInteger ? `${integCoeff}x² + C` : `(${a}/2)x² + C`;

      const options = makeUniqueOptions(ans, () => `${randInt(1, 5)}x² + C`, 4, true);
      return {
        question: `Evaluate the indefinite integral:`,
        visualContent: `<div class="text-3xl font-mono font-bold text-purple-500 my-2">∫ (${a}x) dx</div>`,
        options,
        correctAnswer: ans,
        hint: `Power rule for integration: ∫ xⁿ dx = (xⁿ⁺¹)/(n+1) + C`,
        explanation: `∫ (${a}x) dx = ${a} · (x²/2) + C = ${ans}.`
      };
    }

    default:
      return generateTier4Question("t4_quadratics", difficulty);
  }
}

// Master question dispatcher
function generateQuestion(tierId, topicId, difficulty = 1) {
  switch (tierId) {
    case "tier1":
      return generateTier1Question(topicId, difficulty);
    case "tier2":
      return generateTier2Question(topicId, difficulty);
    case "tier3":
      return generateTier3Question(topicId, difficulty);
    case "tier4":
      return generateTier4Question(topicId, difficulty);
    default:
      return generateTier1Question("t1_counting", difficulty);
  }
}
