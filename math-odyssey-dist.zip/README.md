# 🌌 MathOdyssey: Adaptive Math Activity App & Game (Ages 5 – 18)

**MathOdyssey** is a full-featured, gamified mathematics learning and activity platform designed to scale seamlessly from early childhood (kindergarten) to high-school graduation and college readiness.

Now upgraded with **36 comprehensive math concepts**, **numbered quiz levels (Quiz #1 to #5)**, and **customizable quiz question counts (5, 8, 10, 15, or 20 questions)**!

---

## 🎯 Curriculum Breakdown: 36 Concepts by Age Tiers

### 🌱 Tier 1: Junior Explorers (Ages 5 – 7 | Kindergarten – Grade 2)
1. **Visual Counting**: Count fruits, stars, rockets, and gems with interactive touch items.
2. **Picture Addition & Subtraction**: Visual groups combined or taken away (`🍎🍎 + 🍎 = ?`).
3. **Greater Than / Less Than**: Hungry crocodile comparator (`>`, `<`, `=`).
4. **Pattern Detective**: Repeating sequence recognition (shapes and colors).
5. **Make Ten (Ten-Frame)**: Number bonds adding up to 10 with visual dot frames.
6. **Coin Value & Counting**: Pennies (1¢), Nickels (5¢), and Dimes (10¢).
7. **Telling Time**: Read hours (:00) and half-hours (:30) on clock faces.
8. **2D & 3D Shape Detective**: Sides, corners, and faces of triangles, cubes, spheres, and cylinders.
9. **Odd vs Even Numbers**: Visual paired items identifying whether a number has equal pairs or an odd remainder.

### ⚡ Tier 2: Math Pioneers (Ages 8 – 11 | Grades 3 – 5)
1. **Lightning Multiplication**: Fast times tables up to 12×12 and missing factor quests (`7 × ? = 42`).
2. **Division & Remainders**: Equal-sharing math with whole quotients and remainders (`27 ÷ 4 = 6 R 3`).
3. **Fraction Feast**: Visual slice recognition, like-denominator addition, and fraction simplification.
4. **Real-World Quests**: Practical word problems covering pocket money, time elapsed, and measurements.
5. **Order of Operations (PEMDAS)**: Brackets, multiplication, division, addition, and subtraction rules.
6. **Decimals & Money Math**: Adding and comparing tenths and hundredths.
7. **Area & Perimeter**: Calculate rectangle area ($L \times W$) and perimeter ($2(L + W)$).
8. **Factors & Prime Numbers**: Identify prime numbers and factor pairs.
9. **Data Charts & Graphs**: Read and analyze comparative bar graphs.

### 🚀 Tier 3: Algebra Challengers (Ages 12 – 14 | Grades 6 – 8)
1. **Linear Equations**: Solve for unknown variables ($ax + b = c$, balance methods).
2. **Negative Numbers & Integers**: Master signed integer arithmetic rules ($+$, $-$, $\times$).
3. **Ratios & Percentages**: Sales discounts, percentage calculations, and scaling ratios.
4. **Exponents & Square Roots**: Perfect squares ($\sqrt{144}$), cube roots, and integer powers ($2^5$).
5. **Geometry & Pythagoras**: Right triangle geometry ($a^2 + b^2 = c^2$), hypotenuse and leg lengths.
6. **Scientific Notation**: Express large and small values using powers of 10 ($4.5 \times 10^3$).
7. **Slope & Linear Graphs**: Calculate slope $m$ and $y$-intercept in $y = mx + b$.
8. **Systems of Equations**: Solve simultaneous linear equations ($x+y$ and $x-y$).
9. **Statistics (Mean, Median, Mode, Range)**: Analyze data distributions and find ranges.

### 👑 Tier 4: Master Scholars (Ages 15 – 18 | High School & College Prep)
1. **Quadratic Equations**: Factoring, roots, vertex form, and discriminant analysis ($\Delta = b^2 - 4ac$).
2. **Trigonometry & Unit Circle**: Exact values for $\sin, \cos, \tan$ at special angles ($30^\circ, 45^\circ, 60^\circ, 90^\circ$).
3. **Logarithms & Functions**: Logarithmic bases ($\log_2 32$) and function compositions ($f(g(x))$).
4. **Probability & Combinatorics**: Permutations $P(n,r)$, combinations $C(n,r)$, and odds.
5. **Calculus & Derivatives**: Power rule derivatives ($\frac{d}{dx}[ax^n]$) and algebraic limits.
6. **Matrices & Determinants**: Calculate $2 \times 2$ determinants ($ad - bc$).
7. **Sequences & Series**: Arithmetic progressions and $n$-th term formulas ($a_n = a_1 + (n-1)d$).
8. **Complex Numbers**: Arithmetic with real and imaginary units ($i^2 = -1$).
9. **Antiderivatives & Integrals**: Indefinite power-rule integration ($\int ax\, dx = \frac{a}{2}x^2 + C$).

---

## 🎮 Game Modes & Quiz Stage Controls

1. **Numbered Quiz Stages (Quiz #1 to Quiz #5)**:
   - Each concept features 5 numbered quiz tiers (from Fundamentals to Master Class).
   - Track earned stars (⭐/⭐⭐/⭐⭐⭐) per Quiz Number.
2. **Configurable Quiz Question Count**:
   - Choose between **5 Questions (Quick)**, **8 Questions**, **10 Questions (Standard)**, **15 Questions (Challenge)**, or **20 Questions (Marathon)**.
   - Interactive in-quiz Question Number Bar (`Q1`, `Q2`, `Q3`...) with instant visual feedback (✓ / ✗).
3. **60-Second Speed Blitz**:
   - Rapid-fire countdown timer with combo streak bonuses and personal high scores.
4. **Battle Arena (Vs MathBot / Pass & Play)**:
   - Compete against **MathBot** in 5-round duels.
5. **Interactive Math Lab / Manipulatives**:
   - **Ten-Frame Sandbox** (Ages 5–7): Interactive clickable tokens that visually demonstrate number bonds to 10.
   - **Pizza Fraction Cutter** (Ages 8–11): Real-time SVG pizza with numerator/denominator sliders.
   - **Algebra Equation Balancer** (Ages 12–14): Interactive tilting scale that balances when $x$ is solved.
   - **Trigonometric & Wave Grapher** (Ages 15–18): HTML5 canvas curve plotter with adjustable amplitude and frequency.

---

## 🚀 How to Run

The app is hosted locally on:
👉 **http://localhost:8000**

To launch manually:
```powershell
python -m http.server 8000 --directory "C:\Users\ABHISHEK KUMAR\.gemini\antigravity\scratch\math-odyssey"
```
Or simply double-click `index.html` in file explorer!
