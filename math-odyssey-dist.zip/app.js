// Math Odyssey - Core Application Engine & State Controller
// Enhanced with 36 Concepts, Numbered Quiz Stages (Quiz #1 to #5), and Configurable Quiz Question Counts

const AVATARS = [
  { id: "sprout", name: "Sprout Fox", icon: "🦊" },
  { id: "astro", name: "Astro Cat", icon: "🐱" },
  { id: "owl", name: "Wizard Owl", icon: "🦉" },
  { id: "robot", name: "Robo-1", icon: "🤖" },
  { id: "ninja", name: "Cyber Ninja", icon: "🥷" },
  { id: "dragon", name: "Cosmic Dragon", icon: "🐲" },
  { id: "penguin", name: "Professor Penguin", icon: "🐧" },
  { id: "lion", name: "Math Monarch", icon: "🦁" }
];

const BADGES = [
  { id: "first_step", name: "First Step", icon: "🎯", desc: "Answered your very first math question correctly" },
  { id: "speedy", name: "Lightning Reflex", icon: "⚡", desc: "Answered correctly in under 3 seconds" },
  { id: "streak_5", name: "On Fire!", icon: "🔥", desc: "Reached a 5-question answer streak" },
  { id: "streak_10", name: "Unstoppable", icon: "🌟", desc: "Reached a 10-question flawless streak" },
  { id: "tier1_clear", name: "Junior Explorer", icon: "🌱", desc: "Completed a round in Tier 1 (Ages 5-7)" },
  { id: "tier2_clear", name: "Math Pioneer", icon: "⚔️", desc: "Completed a round in Tier 2 (Ages 8-11)" },
  { id: "tier3_clear", name: "Algebra Ace", icon: "🚀", desc: "Completed a round in Tier 3 (Ages 12-14)" },
  { id: "tier4_clear", name: "Quantum Scholar", icon: "👑", desc: "Completed a round in Tier 4 (Ages 15-18)" },
  { id: "blitz_champ", name: "Speed Demon", icon: "⏱️", desc: "Scored 10+ correct answers in a 60s Speed Blitz" },
  { id: "bot_slayer", name: "Bot Buster", icon: "🤖", desc: "Defeated the AI MathBot in a Battle Arena" },
  { id: "marathon_hero", name: "Marathon Mind", icon: "🏅", desc: "Completed a 15+ question comprehensive quiz" }
];

const App = {
  state: {
    user: {
      name: "Math Hero",
      avatar: "🦊",
      xp: 0,
      level: 1,
      streak: 0,
      bestStreak: 0,
      badges: [],
      quizProgress: {}, // key: topicId_qNum -> stars (1-3)
      highScores: {
        blitz: 0
      }
    },
    currentTierId: "tier1",
    currentTopicId: "t1_counting",
    currentMode: "dashboard", // 'dashboard', 'quest', 'blitz', 'battle', 'lab'
    quizQuestionCount: 10,    // Configurable Quiz Length (5, 8, 10, 15, 20)
    currentQuizNo: 1,         // Numbered Quiz (Quiz #1, Quiz #2, ...)

    // Quest state
    quest: {
      questions: [],
      currentIndex: 0,
      score: 0,
      total: 10,
      combo: 0,
      startTime: 0,
      answered: false,
      answersHistory: [] // tracks true/false for each question answered
    },

    // Blitz state
    blitz: {
      timeLeft: 60,
      timerId: null,
      score: 0,
      combo: 0,
      currentQuestion: null,
      answered: false
    },

    // Battle state
    battle: {
      vsType: "ai",
      aiDifficulty: "medium",
      playerScore: 0,
      opponentScore: 0,
      round: 1,
      totalRounds: 5,
      currentQuestion: null,
      p1Answered: false,
      p2Answered: false,
      isP1Turn: true
    }
  },

  init() {
    this.loadState();
    this.bindEvents();
    this.renderHeader();
    this.renderDashboard();
    MathLab.init();
  },

  loadState() {
    try {
      const saved = localStorage.getItem("math_odyssey_user");
      if (saved) {
        this.state.user = { ...this.state.user, ...JSON.parse(saved) };
      }
    } catch (e) {
      console.warn("Storage unavailable, continuing with default state.");
    }
  },

  saveState() {
    try {
      localStorage.setItem("math_odyssey_user", JSON.stringify(this.state.user));
    } catch (e) {
      console.warn("Storage save error.");
    }
  },

  awardXP(amount) {
    this.state.user.xp += amount;
    const oldLevel = this.state.user.level;
    this.state.user.level = Math.floor(this.state.user.xp / 100) + 1;

    if (this.state.user.level > oldLevel) {
      soundManager.playFanfare();
      confetti.burst(80);
      this.showToast(`🎉 Level Up! You are now Level ${this.state.user.level}!`);
    }
    this.saveState();
    this.renderHeader();
  },

  unlockBadge(badgeId) {
    if (!this.state.user.badges.includes(badgeId)) {
      this.state.user.badges.push(badgeId);
      const b = BADGES.find(x => x.id === badgeId);
      if (b) {
        soundManager.playFanfare();
        confetti.burst(60);
        this.showToast(`🏆 Badge Unlocked: ${b.icon} ${b.name}!`);
      }
      this.saveState();
    }
  },

  showToast(message) {
    const toast = document.getElementById("toastNotification");
    if (!toast) return;
    toast.textContent = message;
    toast.classList.remove("opacity-0", "translate-y-4", "pointer-events-none");
    toast.classList.add("opacity-100", "translate-y-0");

    setTimeout(() => {
      toast.classList.add("opacity-0", "translate-y-4", "pointer-events-none");
      toast.classList.remove("opacity-100", "translate-y-0");
    }, 3200);
  },

  bindEvents() {
    window.addEventListener("keydown", (e) => {
      if (["1", "2", "3", "4"].includes(e.key)) {
        const idx = parseInt(e.key, 10) - 1;
        const buttons = document.querySelectorAll(".option-btn");
        if (buttons[idx]) {
          buttons[idx].click();
        }
      } else if (e.key === " " || e.key === "Enter") {
        const nextBtn = document.getElementById("nextQuestionBtn");
        if (nextBtn && !nextBtn.classList.contains("hidden")) {
          nextBtn.click();
        }
      }
    });
  },

  setTier(tierId) {
    this.state.currentTierId = tierId;
    const tier = CURRICULUM.tiers.find(t => t.id === tierId);
    if (tier && tier.topics.length > 0) {
      this.state.currentTopicId = tier.topics[0].id;
    }
    soundManager.playPop();
    this.renderDashboard();
  },

  setQuizQuestionCount(count) {
    this.state.quizQuestionCount = parseInt(count, 10);
    soundManager.playPop();
    this.renderDashboard();
  },

  // ==========================================
  // HEADER & PROFILE
  // ==========================================
  renderHeader() {
    const u = this.state.user;
    const xpInLevel = u.xp % 100;

    const el = document.getElementById("appHeader");
    if (!el) return;

    el.innerHTML = `
      <div class="max-w-6xl mx-auto flex items-center justify-between gap-4">
        <!-- Logo & Branding -->
        <div class="flex items-center gap-3 cursor-pointer" onclick="App.showDashboard()">
          <div class="w-11 h-11 rounded-2xl bg-gradient-to-tr from-blue-600 to-indigo-500 flex items-center justify-center text-white text-2xl shadow-md transform hover:rotate-6 transition">
            🌌
          </div>
          <div>
            <div class="font-extrabold text-lg sm:text-xl tracking-tight bg-gradient-to-r from-blue-600 via-indigo-600 to-purple-600 dark:from-blue-400 dark:to-purple-400 bg-clip-text text-transparent">
              MathOdyssey
            </div>
            <div class="text-[11px] font-semibold text-slate-400 -mt-1 hidden sm:block">Ages 5 to 18 • 36 Interactive Math Concepts</div>
          </div>
        </div>

        <!-- User Stats Bar -->
        <div class="flex items-center gap-2 sm:gap-4">
          <!-- Level & XP -->
          <div class="flex items-center gap-2 bg-slate-100 dark:bg-slate-800/80 px-3 py-1.5 rounded-2xl border border-slate-200 dark:border-slate-700/60 shadow-sm cursor-pointer hover:bg-slate-200 transition" onclick="App.openProfileModal()">
            <span class="text-xl">${u.avatar}</span>
            <div class="hidden sm:block text-left">
              <div class="text-xs font-bold text-slate-700 dark:text-slate-200">Lvl ${u.level} • ${u.name}</div>
              <div class="w-20 bg-slate-300 dark:bg-slate-700 h-1.5 rounded-full overflow-hidden mt-0.5">
                <div class="bg-gradient-to-r from-blue-500 to-indigo-500 h-full" style="width: ${xpInLevel}%"></div>
              </div>
            </div>
            <span class="text-xs font-extrabold text-blue-600 dark:text-blue-400">${u.xp} XP</span>
          </div>

          <!-- Streak Counter -->
          <div class="flex items-center gap-1 bg-amber-50 dark:bg-amber-950/40 border border-amber-300 dark:border-amber-700/60 px-2.5 py-1.5 rounded-2xl text-amber-600 dark:text-amber-400 text-xs font-bold">
            <span>🔥</span>
            <span>${u.streak}</span>
          </div>

          <!-- Audio Toggle -->
          <button id="soundToggleBtn" onclick="App.toggleSound()" class="w-9 h-9 rounded-xl bg-slate-100 dark:bg-slate-800 hover:bg-slate-200 dark:hover:bg-slate-700 flex items-center justify-center text-slate-600 dark:text-slate-300 transition text-base" title="Toggle Sound">
            ${soundManager.enabled ? "🔊" : "🔇"}
          </button>
        </div>
      </div>
    `;
  },

  toggleSound() {
    const isEnabled = soundManager.toggle();
    const btn = document.getElementById("soundToggleBtn");
    if (btn) btn.innerHTML = isEnabled ? "🔊" : "🔇";
    if (isEnabled) soundManager.playPop();
  },

  openProfileModal() {
    soundManager.playPop();
    const modal = document.getElementById("profileModal");
    if (!modal) return;

    const u = this.state.user;
    const badgeCards = BADGES.map(b => {
      const isUnlocked = u.badges.includes(b.id);
      return `
        <div class="p-3 rounded-2xl border transition-all ${
          isUnlocked
            ? 'bg-amber-50 dark:bg-amber-950/40 border-amber-300 dark:border-amber-700 text-slate-800 dark:text-slate-100'
            : 'bg-slate-100 dark:bg-slate-800/40 border-slate-200 dark:border-slate-800 opacity-40 grayscale'
        }">
          <div class="text-2xl">${b.icon}</div>
          <div class="text-xs font-bold mt-1">${b.name}</div>
          <div class="text-[10px] text-slate-500 dark:text-slate-400 leading-tight">${b.desc}</div>
        </div>
      `;
    }).join("");

    const avatarBtns = AVATARS.map(av => `
      <button onclick="App.selectAvatar('${av.icon}', '${av.name}')" class="w-12 h-12 rounded-2xl text-2xl flex items-center justify-center border-2 transition ${u.avatar === av.icon ? 'border-blue-500 bg-blue-50 dark:bg-blue-950/60 scale-110 shadow' : 'border-slate-200 dark:border-slate-700 hover:scale-105'}">
        ${av.icon}
      </button>
    `).join("");

    modal.innerHTML = `
      <div class="bg-white dark:bg-slate-900 border border-slate-200 dark:border-slate-800 rounded-3xl p-6 max-w-lg w-full shadow-2xl relative animate-scaleUp max-h-[90vh] overflow-y-auto">
        <button onclick="App.closeProfileModal()" class="absolute top-4 right-4 text-slate-400 hover:text-slate-600 dark:hover:text-slate-200 text-xl font-bold">✕</button>

        <div class="text-center space-y-2">
          <div class="text-5xl">${u.avatar}</div>
          <input type="text" id="profileNameInput" value="${u.name}" onchange="App.updateName(this.value)" class="text-xl font-extrabold text-center bg-transparent border-b-2 border-slate-300 focus:border-blue-500 outline-none px-2 py-1" />
          <div class="text-xs text-slate-500">Level ${u.level} Explorer • Total ${u.xp} XP</div>
        </div>

        <div class="mt-6">
          <label class="text-xs font-bold uppercase tracking-wider text-slate-400">Choose Your Hero Avatar</label>
          <div class="flex flex-wrap gap-2 justify-center mt-2">
            ${avatarBtns}
          </div>
        </div>

        <div class="mt-6">
          <label class="text-xs font-bold uppercase tracking-wider text-slate-400">Achievements & Badges (${u.badges.length}/${BADGES.length})</label>
          <div class="grid grid-cols-2 sm:grid-cols-3 gap-2.5 mt-2">
            ${badgeCards}
          </div>
        </div>

        <div class="mt-6 flex justify-end">
          <button onclick="App.closeProfileModal()" class="px-5 py-2 bg-blue-600 hover:bg-blue-700 text-white font-semibold rounded-xl text-sm">Done</button>
        </div>
      </div>
    `;

    modal.classList.remove("hidden");
    modal.classList.add("flex");
  },

  selectAvatar(icon, defaultName) {
    this.state.user.avatar = icon;
    soundManager.playPop();
    this.saveState();
    this.renderHeader();
    this.openProfileModal();
  },

  updateName(name) {
    if (name.trim()) {
      this.state.user.name = name.trim();
      this.saveState();
      this.renderHeader();
    }
  },

  closeProfileModal() {
    const modal = document.getElementById("profileModal");
    if (!modal) return;
    modal.classList.add("hidden");
    modal.classList.remove("flex");
  },

  // ==========================================
  // DASHBOARD & TIER SELECTION
  // ==========================================
  showDashboard() {
    this.state.currentMode = "dashboard";
    this.renderDashboard();
  },

  renderDashboard() {
    const main = document.getElementById("mainContent");
    if (!main) return;

    const currentTier = CURRICULUM.tiers.find(t => t.id === this.state.currentTierId) || CURRICULUM.tiers[0];

    // Tier Tabs
    const tierTabsHtml = CURRICULUM.tiers.map(t => {
      const active = t.id === this.state.currentTierId;
      return `
        <button onclick="App.setTier('${t.id}')" class="flex-1 min-w-[140px] p-3 sm:p-4 rounded-2xl text-left border-2 transition-all relative overflow-hidden group ${
          active
            ? 'border-blue-500 bg-white dark:bg-slate-900 shadow-md ring-2 ring-blue-500/20'
            : 'border-slate-200 dark:border-slate-800 bg-slate-50/70 dark:bg-slate-800/40 hover:border-slate-300 dark:hover:border-slate-700'
        }">
          <div class="flex items-center justify-between mb-1">
            <span class="text-2xl">${t.icon}</span>
            <span class="text-[11px] font-bold px-2 py-0.5 rounded-full ${active ? 'bg-blue-100 dark:bg-blue-900/60 text-blue-600 dark:text-blue-300' : 'bg-slate-200 dark:bg-slate-700 text-slate-500'}">${t.ageRange}</span>
          </div>
          <div class="font-bold text-sm sm:text-base text-slate-800 dark:text-slate-100">${t.name}</div>
          <div class="text-[11px] text-slate-500 dark:text-slate-400 truncate">${t.topics.length} Concepts • ${t.grade}</div>
        </button>
      `;
    }).join("");

    // Topics in Current Tier
    const topicCardsHtml = currentTier.topics.map(tp => {
      // Check earned stars on Quiz #1 for this topic
      const key = `${tp.id}_q1`;
      const starsEarned = this.state.user.quizProgress[key] || 0;
      let starDisplay = "☆☆☆";
      if (starsEarned === 1) starDisplay = "⭐☆☆";
      else if (starsEarned === 2) starDisplay = "⭐⭐☆";
      else if (starsEarned === 3) starDisplay = "⭐⭐⭐";

      return `
        <div class="bg-white dark:bg-slate-900 border border-slate-200 dark:border-slate-800 rounded-3xl p-5 hover:shadow-lg hover:border-blue-300 dark:hover:border-blue-700 transition flex flex-col justify-between group">
          <div>
            <div class="flex items-center justify-between mb-2">
              <span class="text-3xl p-2.5 rounded-2xl bg-slate-100 dark:bg-slate-800 group-hover:scale-110 transition-transform">${tp.icon}</span>
              <span class="text-xs font-bold text-amber-500 tracking-wider">${starDisplay}</span>
            </div>
            <h4 class="font-bold text-base text-slate-800 dark:text-slate-100 group-hover:text-blue-600 dark:group-hover:text-blue-400 transition-colors">${tp.title}</h4>
            <p class="text-xs text-slate-500 dark:text-slate-400 mt-1 leading-relaxed">${tp.desc}</p>
          </div>

          <!-- Quick Quiz Stage Buttons -->
          <div class="mt-4 pt-3 border-t border-slate-100 dark:border-slate-800 space-y-2">
            <div class="flex items-center justify-between text-[11px] font-bold text-slate-400">
              <span>Select Quiz No:</span>
              <span class="text-blue-600 dark:text-blue-400">${this.state.quizQuestionCount} Questions</span>
            </div>
            <div class="grid grid-cols-5 gap-1">
              ${[1, 2, 3, 4, 5].map(qNo => `
                <button onclick="App.startNumberedQuiz('${currentTier.id}', '${tp.id}', ${qNo})" class="py-1.5 rounded-lg text-xs font-extrabold border transition ${
                  qNo === 1 ? 'bg-blue-50 dark:bg-blue-950/60 border-blue-300 text-blue-600' : 'bg-slate-100 dark:bg-slate-800 border-slate-200 dark:border-slate-700 text-slate-600 dark:text-slate-300 hover:border-blue-400'
                }" title="Launch Quiz #${qNo}">
                  #${qNo}
                </button>
              `).join("")}
            </div>

            <button onclick="App.startNumberedQuiz('${currentTier.id}', '${tp.id}', 1)" class="w-full py-2 px-3 bg-gradient-to-r ${currentTier.color} text-white font-bold text-xs rounded-xl shadow-xs hover:opacity-95 transition flex items-center justify-center gap-1.5 mt-1">
              <span>Start Quiz #1 (${this.state.quizQuestionCount} Qs)</span>
              <span>➔</span>
            </button>
          </div>
        </div>
      `;
    }).join("");

    main.innerHTML = `
      <div class="space-y-8 animate-fadeIn">
        <!-- Hero Banner with Game Modes -->
        <div class="relative overflow-hidden rounded-3xl p-6 sm:p-8 bg-gradient-to-br from-indigo-900 via-blue-900 to-slate-900 text-white shadow-xl">
          <div class="relative z-10 max-w-2xl space-y-3">
            <div class="inline-flex items-center gap-2 px-3 py-1 rounded-full bg-white/10 backdrop-blur-md border border-white/20 text-xs font-bold text-amber-300">
              <span>✨</span> 36 Concepts • Ages 5 to 18 • Adaptive Math Universe
            </div>
            <h2 class="text-2xl sm:text-4xl font-extrabold tracking-tight">
              Level Up Your Math Skills With Play!
            </h2>
            <p class="text-slate-300 text-sm sm:text-base leading-relaxed">
              Tailored math adventures from kindergarten visual counting up to high-school trigonometry, matrices, and calculus.
            </p>

            <div class="flex flex-wrap gap-3 pt-2">
              <button onclick="App.startSpeedBlitz()" class="px-5 py-2.5 rounded-xl bg-amber-500 hover:bg-amber-400 text-slate-950 font-black text-sm flex items-center gap-2 shadow-lg transition transform hover:-translate-y-0.5">
                <span>⏱️</span> 60s Speed Blitz
              </button>
              <button onclick="App.startBattleArena()" class="px-5 py-2.5 rounded-xl bg-purple-600 hover:bg-purple-500 text-white font-black text-sm flex items-center gap-2 shadow-lg transition transform hover:-translate-y-0.5">
                <span>⚔️</span> Battle Arena (Vs AI / 2P)
              </button>
              <button onclick="App.showMathLab()" class="px-5 py-2.5 rounded-xl bg-white/10 hover:bg-white/20 backdrop-blur-md border border-white/20 text-white font-black text-sm flex items-center gap-2 shadow-lg transition transform hover:-translate-y-0.5">
                <span>🔬</span> Interactive Math Lab
              </button>
            </div>
          </div>

          <div class="absolute -right-8 -bottom-8 w-64 h-64 bg-blue-500/20 rounded-full blur-3xl pointer-events-none"></div>
          <div class="absolute right-12 top-6 text-7xl opacity-20 pointer-events-none hidden md:block">📐</div>
        </div>

        <!-- Quiz Length (Question Count) Control Bar -->
        <div class="p-4 rounded-3xl bg-white dark:bg-slate-900 border border-slate-200 dark:border-slate-800 shadow-sm flex flex-col sm:flex-row items-center justify-between gap-3">
          <div class="flex items-center gap-2">
            <span class="text-xl">⚙️</span>
            <div>
              <div class="font-extrabold text-sm text-slate-800 dark:text-slate-100">Quiz Question Count (Quiz Length)</div>
              <div class="text-[11px] text-slate-400">Choose how many questions to play per quiz session</div>
            </div>
          </div>
          <div class="flex items-center gap-1.5 bg-slate-100 dark:bg-slate-800 p-1.5 rounded-2xl">
            ${[5, 8, 10, 15, 20].map(cnt => `
              <button onclick="App.setQuizQuestionCount(${cnt})" class="px-3 py-1.5 rounded-xl text-xs font-black transition ${
                this.state.quizQuestionCount === cnt
                  ? 'bg-blue-600 text-white shadow'
                  : 'text-slate-600 dark:text-slate-300 hover:bg-slate-200 dark:hover:bg-slate-700'
              }">
                ${cnt} Qs
              </button>
            `).join("")}
          </div>
        </div>

        <!-- Tier Navigation Header -->
        <div class="space-y-3">
          <div class="flex items-center justify-between">
            <h3 class="font-extrabold text-lg text-slate-800 dark:text-slate-100 flex items-center gap-2">
              <span>Select Age & Grade Level</span>
            </h3>
            <span class="text-xs text-slate-400">Click a tier to explore concepts</span>
          </div>
          <div class="grid grid-cols-2 lg:grid-cols-4 gap-3">
            ${tierTabsHtml}
          </div>
        </div>

        <!-- Current Tier Active Header -->
        <div class="p-5 rounded-3xl bg-slate-100 dark:bg-slate-800/60 border border-slate-200 dark:border-slate-700/60 flex flex-col sm:flex-row items-start sm:items-center justify-between gap-4">
          <div class="flex items-center gap-3">
            <span class="text-4xl p-3 bg-white dark:bg-slate-800 rounded-2xl shadow-sm">${currentTier.icon}</span>
            <div>
              <div class="font-black text-lg text-slate-800 dark:text-slate-100">${currentTier.name} (${currentTier.ageRange}) • ${currentTier.topics.length} Concepts</div>
              <div class="text-xs text-slate-500 dark:text-slate-400">${currentTier.description}</div>
            </div>
          </div>
          <button onclick="App.startRandomQuest('${currentTier.id}')" class="px-4 py-2 bg-blue-600 hover:bg-blue-700 text-white rounded-xl text-xs font-bold transition flex items-center gap-1.5 self-stretch sm:self-auto justify-center shadow">
            <span>🎲</span> Play Mixed (${this.state.quizQuestionCount} Questions)
          </button>
        </div>

        <!-- Topics Grid -->
        <div class="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-3 gap-4">
          ${topicCardsHtml}
        </div>
      </div>
    `;
  },

  // ==========================================
  // NUMBERED QUIZ & QUEST CONTROLLER
  // ==========================================
  startNumberedQuiz(tierId, topicId, quizNo = 1) {
    this.state.currentTierId = tierId;
    this.state.currentTopicId = topicId;
    this.state.currentQuizNo = quizNo;
    this.startQuest(tierId, topicId, this.state.quizQuestionCount, quizNo);
  },

  startQuest(tierId, topicId, questionCount = 10, quizNo = 1) {
    this.state.currentMode = "quest";
    this.state.currentTierId = tierId;
    this.state.currentTopicId = topicId;
    this.state.currentQuizNo = quizNo;

    const questions = [];
    for (let i = 0; i < questionCount; i++) {
      // Increase difficulty based on Quiz No and question progress
      const difficulty = (quizNo > 2 || i >= Math.floor(questionCount / 2)) ? 2 : 1;
      questions.push(generateQuestion(tierId, topicId, difficulty));
    }

    this.state.quest = {
      questions,
      currentIndex: 0,
      score: 0,
      total: questions.length,
      combo: 0,
      startTime: Date.now(),
      answered: false,
      answersHistory: new Array(questions.length).fill(null)
    };

    soundManager.playPop();
    this.renderQuestQuestion();
  },

  startRandomQuest(tierId) {
    this.state.currentMode = "quest";
    this.state.currentTierId = tierId;
    this.state.currentQuizNo = 1;
    const tier = CURRICULUM.tiers.find(t => t.id === tierId) || CURRICULUM.tiers[0];
    const questionCount = this.state.quizQuestionCount;

    const questions = [];
    for (let i = 0; i < questionCount; i++) {
      const randomTopic = tier.topics[randInt(0, tier.topics.length - 1)].id;
      const difficulty = i >= Math.floor(questionCount / 2) ? 2 : 1;
      questions.push(generateQuestion(tierId, randomTopic, difficulty));
    }

    this.state.quest = {
      questions,
      currentIndex: 0,
      score: 0,
      total: questions.length,
      combo: 0,
      startTime: Date.now(),
      answered: false,
      answersHistory: new Array(questions.length).fill(null)
    };

    soundManager.playPop();
    this.renderQuestQuestion();
  },

  renderQuestQuestion() {
    const qState = this.state.quest;
    const currentQ = qState.questions[qState.currentIndex];
    const main = document.getElementById("mainContent");
    if (!main || !currentQ) return;

    qState.answered = false;
    qState.startTime = Date.now();

    const progressPct = ((qState.currentIndex) / qState.total) * 100;
    const tier = CURRICULUM.tiers.find(t => t.id === this.state.currentTierId);
    const topic = tier?.topics.find(tp => tp.id === this.state.currentTopicId);

    // Numbered Question Chips Navigator: [Q1] [Q2] [Q3] ...
    const questionChipsHtml = qState.questions.map((_, idx) => {
      const status = qState.answersHistory[idx];
      let chipClass = "bg-slate-100 dark:bg-slate-800 text-slate-400 border border-slate-200 dark:border-slate-700";
      let statusIcon = `${idx + 1}`;

      if (idx === qState.currentIndex) {
        chipClass = "bg-blue-600 text-white font-extrabold ring-2 ring-blue-400 scale-105 shadow";
      } else if (status === true) {
        chipClass = "bg-emerald-100 dark:bg-emerald-950/60 text-emerald-600 border border-emerald-400 font-bold";
        statusIcon = "✓";
      } else if (status === false) {
        chipClass = "bg-rose-100 dark:bg-rose-950/60 text-rose-600 border border-rose-400 font-bold";
        statusIcon = "✗";
      }

      return `
        <div class="w-7 h-7 sm:w-8 sm:h-8 rounded-xl flex items-center justify-center text-xs transition-all shrink-0 font-mono ${chipClass}">
          ${statusIcon}
        </div>
      `;
    }).join("");

    const optionsHtml = currentQ.options.map((opt, idx) => `
      <button onclick="App.handleQuestAnswer('${opt}', this)" class="option-btn p-4 sm:p-5 rounded-2xl border-2 border-slate-200 dark:border-slate-700 bg-white dark:bg-slate-900 hover:border-blue-500 hover:bg-blue-50 dark:hover:bg-blue-950/40 text-slate-800 dark:text-slate-100 font-bold text-lg sm:text-xl transition-all shadow-sm transform hover:-translate-y-0.5 active:translate-y-0 text-center flex items-center justify-between">
        <span class="w-7 h-7 rounded-lg bg-slate-100 dark:bg-slate-800 text-slate-500 text-xs flex items-center justify-center font-mono">${idx + 1}</span>
        <span class="flex-1 text-center font-mono">${opt}</span>
      </button>
    `).join("");

    main.innerHTML = `
      <div class="max-w-2xl mx-auto space-y-5 animate-fadeIn">
        <!-- Top Quiz Header & Number indicator -->
        <div class="flex items-center justify-between text-xs font-bold text-slate-500">
          <button onclick="App.showDashboard()" class="flex items-center gap-1 hover:text-slate-700 dark:hover:text-slate-300">
            <span>✕</span> Exit Quiz
          </button>
          <div class="flex items-center gap-2">
            <span class="px-2.5 py-1 rounded-full bg-blue-100 dark:bg-blue-900/60 text-blue-600 dark:text-blue-300 font-extrabold">
              🎯 Quiz #${this.state.currentQuizNo}
            </span>
            <span>Question ${qState.currentIndex + 1} of ${qState.total}</span>
          </div>
          <span class="text-amber-500 font-bold">⭐ ${qState.score}</span>
        </div>

        <!-- Question Number Chips Bar -->
        <div class="flex items-center gap-1.5 overflow-x-auto p-2 bg-white dark:bg-slate-900 border border-slate-200 dark:border-slate-800 rounded-2xl shadow-xs">
          ${questionChipsHtml}
        </div>

        <!-- Continuous Progress bar -->
        <div class="w-full bg-slate-200 dark:bg-slate-700 h-1.5 rounded-full overflow-hidden">
          <div class="bg-gradient-to-r from-blue-500 to-indigo-600 h-full transition-all duration-300" style="width: ${progressPct}%"></div>
        </div>

        <!-- Question Card -->
        <div class="bg-white dark:bg-slate-900 border border-slate-200 dark:border-slate-800 rounded-3xl p-6 sm:p-8 text-center shadow-lg relative overflow-hidden">
          <div class="inline-block px-3 py-1 rounded-full bg-slate-100 dark:bg-slate-800 text-slate-600 dark:text-slate-400 text-xs font-bold mb-3">
            ${topic ? topic.title : (tier ? tier.name : 'Adventure')}
          </div>

          <h3 class="text-xl sm:text-2xl font-black text-slate-900 dark:text-slate-100 mb-2">
            ${currentQ.question}
          </h3>

          ${currentQ.visualContent || ''}

          <!-- Hint Toggle Button -->
          <div class="mt-4">
            <button onclick="App.toggleHint()" id="hintBtn" class="text-xs font-semibold text-blue-600 dark:text-blue-400 hover:underline inline-flex items-center gap-1">
              <span>💡 Need a hint?</span>
            </button>
            <div id="hintBox" class="hidden mt-2 p-3 bg-amber-50 dark:bg-amber-950/40 border border-amber-200 dark:border-amber-800 rounded-xl text-xs text-amber-800 dark:text-amber-300">
              ${currentQ.hint}
            </div>
          </div>
        </div>

        <!-- Options Grid -->
        <div class="grid grid-cols-1 sm:grid-cols-2 gap-3">
          ${optionsHtml}
        </div>

        <!-- Explanation & Next Button Container -->
        <div id="explanationContainer" class="hidden space-y-4 animate-scaleUp">
          <div id="explanationBox" class="p-4 rounded-2xl border text-sm font-medium"></div>
          <button id="nextQuestionBtn" onclick="App.nextQuestQuestion()" class="w-full py-4 bg-blue-600 hover:bg-blue-700 text-white font-extrabold rounded-2xl text-base shadow-lg transition">
            Continue ➔
          </button>
        </div>
      </div>
    `;
  },

  toggleHint() {
    const hintBox = document.getElementById("hintBox");
    if (!hintBox) return;
    hintBox.classList.toggle("hidden");
    soundManager.playPop();
  },

  handleQuestAnswer(selectedVal, btnElement) {
    const qState = this.state.quest;
    if (qState.answered) return;
    qState.answered = true;

    const currentQ = qState.questions[qState.currentIndex];
    const isCorrect = selectedVal.toString() === currentQ.correctAnswer.toString();
    const elapsedSec = (Date.now() - qState.startTime) / 1000;

    // Record question history
    qState.answersHistory[qState.currentIndex] = isCorrect;

    const explContainer = document.getElementById("explanationContainer");
    const explBox = document.getElementById("explanationBox");

    // Disable all options
    document.querySelectorAll(".option-btn").forEach(btn => {
      btn.disabled = true;
      btn.classList.add("cursor-default");
    });

    if (isCorrect) {
      soundManager.playCorrect();
      btnElement.classList.remove("border-slate-200", "dark:border-slate-700");
      btnElement.classList.add("border-emerald-500", "bg-emerald-100", "dark:bg-emerald-950/60", "text-emerald-700", "dark:text-emerald-300");

      qState.score++;
      qState.combo++;
      this.state.user.streak++;
      if (this.state.user.streak > this.state.user.bestStreak) {
        this.state.user.bestStreak = this.state.user.streak;
      }

      this.awardXP(15 + Math.min(20, qState.combo * 2));
      this.unlockBadge("first_step");

      if (elapsedSec < 3) {
        this.unlockBadge("speedy");
      }
      if (qState.combo >= 5) {
        soundManager.playCombo(qState.combo);
        confetti.burst(40);
        this.unlockBadge("streak_5");
      }
      if (qState.combo >= 10) {
        this.unlockBadge("streak_10");
      }

      explBox.className = "p-4 rounded-2xl border border-emerald-300 bg-emerald-50 dark:bg-emerald-950/50 text-emerald-900 dark:text-emerald-200";
      explBox.innerHTML = `
        <div class="font-black text-emerald-600 dark:text-emerald-400 text-base mb-1">🎉 Awesome Job! Correct!</div>
        <div class="text-xs sm:text-sm whitespace-pre-line">${currentQ.explanation}</div>
      `;
    } else {
      soundManager.playWrong();
      btnElement.classList.remove("border-slate-200", "dark:border-slate-700");
      btnElement.classList.add("border-rose-500", "bg-rose-100", "dark:bg-rose-950/60", "text-rose-700", "dark:text-rose-300");

      qState.combo = 0;
      this.state.user.streak = 0;

      // Highlight the correct answer button
      document.querySelectorAll(".option-btn").forEach(btn => {
        if (btn.querySelector("span.flex-1").textContent.trim() === currentQ.correctAnswer.toString()) {
          btn.classList.add("border-emerald-500", "bg-emerald-50", "dark:bg-emerald-950/40");
        }
      });

      explBox.className = "p-4 rounded-2xl border border-rose-300 bg-rose-50 dark:bg-rose-950/50 text-rose-900 dark:text-rose-200";
      explBox.innerHTML = `
        <div class="font-black text-rose-600 dark:text-rose-400 text-base mb-1">💡 Good try! The right answer is ${currentQ.correctAnswer}</div>
        <div class="text-xs sm:text-sm whitespace-pre-line">${currentQ.explanation}</div>
      `;
    }

    this.saveState();
    this.renderHeader();
    explContainer.classList.remove("hidden");
  },

  nextQuestQuestion() {
    const qState = this.state.quest;
    qState.currentIndex++;

    if (qState.currentIndex < qState.total) {
      soundManager.playPop();
      this.renderQuestQuestion();
    } else {
      this.renderQuestResults();
    }
  },

  renderQuestResults() {
    const qState = this.state.quest;
    const pct = Math.round((qState.score / qState.total) * 100);
    const main = document.getElementById("mainContent");
    if (!main) return;

    soundManager.playFanfare();
    confetti.burst(90);

    // Save stars for this Quiz Stage
    let starCount = 1;
    let starIcons = "⭐☆☆";
    if (pct >= 85) {
      starCount = 3;
      starIcons = "⭐⭐⭐";
    } else if (pct >= 50) {
      starCount = 2;
      starIcons = "⭐⭐☆";
    }

    const key = `${this.state.currentTopicId}_q${this.state.currentQuizNo}`;
    if (!this.state.user.quizProgress[key] || starCount > this.state.user.quizProgress[key]) {
      this.state.user.quizProgress[key] = starCount;
      this.saveState();
    }

    // Badges
    if (this.state.currentTierId === "tier1") this.unlockBadge("tier1_clear");
    if (this.state.currentTierId === "tier2") this.unlockBadge("tier2_clear");
    if (this.state.currentTierId === "tier3") this.unlockBadge("tier3_clear");
    if (this.state.currentTierId === "tier4") this.unlockBadge("tier4_clear");
    if (qState.total >= 15) this.unlockBadge("marathon_hero");

    main.innerHTML = `
      <div class="max-w-md mx-auto space-y-6 text-center animate-scaleUp">
        <div class="p-8 bg-white dark:bg-slate-900 border border-slate-200 dark:border-slate-800 rounded-3xl shadow-xl space-y-4">
          <div class="text-5xl">${starIcons}</div>
          <h2 class="text-3xl font-black text-slate-900 dark:text-slate-100">Quiz #${this.state.currentQuizNo} Completed!</h2>
          <p class="text-slate-500 text-sm">You solved ${qState.score} out of ${qState.total} correctly (${pct}% accuracy)!</p>

          <div class="grid grid-cols-2 gap-3 py-4 border-y border-slate-100 dark:border-slate-800">
            <div class="p-3 bg-slate-50 dark:bg-slate-800/60 rounded-2xl">
              <div class="text-xs text-slate-400 font-bold uppercase">Accuracy</div>
              <div class="text-2xl font-black text-blue-600">${qState.score} / ${qState.total}</div>
            </div>
            <div class="p-3 bg-slate-50 dark:bg-slate-800/60 rounded-2xl">
              <div class="text-xs text-slate-400 font-bold uppercase">XP Earned</div>
              <div class="text-2xl font-black text-emerald-600">+${qState.score * 15}</div>
            </div>
          </div>

          <div class="space-y-3 pt-2">
            ${this.state.currentQuizNo < 5 ? `
              <button onclick="App.startNumberedQuiz('${this.state.currentTierId}', '${this.state.currentTopicId}', ${this.state.currentQuizNo + 1})" class="w-full py-3.5 bg-gradient-to-r from-emerald-500 to-teal-600 text-white font-extrabold rounded-2xl text-sm transition shadow-md flex items-center justify-center gap-2">
                <span>Play Next Quiz #${this.state.currentQuizNo + 1}</span>
                <span>➔</span>
              </button>
            ` : ''}
            <button onclick="App.startNumberedQuiz('${this.state.currentTierId}', '${this.state.currentTopicId}', ${this.state.currentQuizNo})" class="w-full py-3 bg-blue-600 hover:bg-blue-700 text-white font-extrabold rounded-2xl text-sm transition shadow-md">
              Replay Quiz #${this.state.currentQuizNo} ↺
            </button>
            <button onclick="App.showDashboard()" class="w-full py-3 bg-slate-100 dark:bg-slate-800 hover:bg-slate-200 text-slate-700 dark:text-slate-300 font-bold rounded-2xl text-sm transition">
              Back to Dashboard
            </button>
          </div>
        </div>
      </div>
    `;
  },

  // ==========================================
  // MODE 2: 60-SECOND SPEED BLITZ
  // ==========================================
  startSpeedBlitz() {
    this.state.currentMode = "blitz";
    const bState = this.state.blitz;
    bState.timeLeft = 60;
    bState.score = 0;
    bState.combo = 0;
    bState.answered = false;

    if (bState.timerId) clearInterval(bState.timerId);

    soundManager.playPop();
    this.renderBlitzScreen();

    bState.timerId = setInterval(() => {
      bState.timeLeft--;
      const timerEl = document.getElementById("blitzTimerDisplay");
      if (timerEl) {
        timerEl.textContent = bState.timeLeft;
        if (bState.timeLeft <= 10) {
          timerEl.classList.add("text-rose-500", "animate-pulse");
          soundManager.playTick();
        }
      }

      if (bState.timeLeft <= 0) {
        clearInterval(bState.timerId);
        this.finishSpeedBlitz();
      }
    }, 1000);

    this.nextBlitzQuestion();
  },

  renderBlitzScreen() {
    const main = document.getElementById("mainContent");
    if (!main) return;

    main.innerHTML = `
      <div class="max-w-2xl mx-auto space-y-6 animate-fadeIn">
        <div class="flex items-center justify-between p-4 bg-white dark:bg-slate-900 border border-slate-200 dark:border-slate-800 rounded-3xl shadow-sm">
          <button onclick="App.cancelSpeedBlitz()" class="text-xs font-bold text-slate-400 hover:text-slate-600">✕ Quit</button>

          <div class="flex items-center gap-2">
            <span class="text-xl">⏱️</span>
            <span id="blitzTimerDisplay" class="font-black text-2xl text-amber-500 font-mono">60</span>
            <span class="text-xs text-slate-400">sec</span>
          </div>

          <div class="flex items-center gap-3">
            <div class="text-right">
              <div class="text-[10px] uppercase font-bold text-slate-400">Score</div>
              <div id="blitzScoreDisplay" class="font-black text-xl text-blue-600 font-mono">0</div>
            </div>
            <div id="blitzComboBadge" class="hidden px-2 py-1 bg-amber-500 text-slate-950 font-black text-xs rounded-xl animate-bounce">
              x1 Combo
            </div>
          </div>
        </div>

        <div id="blitzQuestionCardContainer"></div>
      </div>
    `;
  },

  nextBlitzQuestion() {
    const bState = this.state.blitz;
    bState.answered = false;

    const tier = CURRICULUM.tiers.find(t => t.id === this.state.currentTierId) || CURRICULUM.tiers[0];
    const topic = tier.topics[randInt(0, tier.topics.length - 1)];
    bState.currentQuestion = generateQuestion(tier.id, topic.id, 1);

    const cardContainer = document.getElementById("blitzQuestionCardContainer");
    if (!cardContainer) return;

    const optionsHtml = bState.currentQuestion.options.map((opt) => `
      <button onclick="App.handleBlitzAnswer('${opt}', this)" class="option-btn p-4 rounded-2xl border-2 border-slate-200 dark:border-slate-700 bg-white dark:bg-slate-900 hover:border-amber-500 font-bold text-lg transition shadow-sm text-center font-mono">
        ${opt}
      </button>
    `).join("");

    cardContainer.innerHTML = `
      <div class="space-y-5 animate-scaleUp">
        <div class="bg-white dark:bg-slate-900 border border-slate-200 dark:border-slate-800 rounded-3xl p-6 text-center shadow-lg">
          <div class="text-xs font-bold text-amber-500 uppercase tracking-widest mb-1">Speed Sprint</div>
          <h3 class="text-2xl font-black text-slate-900 dark:text-slate-100">${bState.currentQuestion.question}</h3>
          ${bState.currentQuestion.visualContent || ''}
        </div>
        <div class="grid grid-cols-2 gap-3">
          ${optionsHtml}
        </div>
      </div>
    `;
  },

  handleBlitzAnswer(selectedVal, btnElement) {
    const bState = this.state.blitz;
    if (bState.answered) return;
    bState.answered = true;

    const isCorrect = selectedVal.toString() === bState.currentQuestion.correctAnswer.toString();

    if (isCorrect) {
      soundManager.playCorrect();
      bState.score++;
      bState.combo++;
      this.awardXP(10);

      const scoreDisplay = document.getElementById("blitzScoreDisplay");
      if (scoreDisplay) scoreDisplay.textContent = bState.score;

      const comboBadge = document.getElementById("blitzComboBadge");
      if (comboBadge && bState.combo > 1) {
        comboBadge.textContent = `x${bState.combo} Combo!`;
        comboBadge.classList.remove("hidden");
      }

      btnElement.classList.add("bg-emerald-500", "text-white", "border-emerald-600");
    } else {
      soundManager.playWrong();
      bState.combo = 0;
      const comboBadge = document.getElementById("blitzComboBadge");
      if (comboBadge) comboBadge.classList.add("hidden");
      btnElement.classList.add("bg-rose-500", "text-white", "border-rose-600");
    }

    setTimeout(() => {
      if (bState.timeLeft > 0) {
        this.nextBlitzQuestion();
      }
    }, 350);
  },

  cancelSpeedBlitz() {
    if (this.state.blitz.timerId) clearInterval(this.state.blitz.timerId);
    this.showDashboard();
  },

  finishSpeedBlitz() {
    soundManager.playFanfare();
    confetti.burst(100);

    const score = this.state.blitz.score;
    if (score > this.state.user.highScores.blitz) {
      this.state.user.highScores.blitz = score;
    }
    if (score >= 10) {
      this.unlockBadge("blitz_champ");
    }
    this.saveState();

    const main = document.getElementById("mainContent");
    if (!main) return;

    main.innerHTML = `
      <div class="max-w-md mx-auto space-y-6 text-center animate-scaleUp">
        <div class="p-8 bg-white dark:bg-slate-900 border border-slate-200 dark:border-slate-800 rounded-3xl shadow-xl space-y-4">
          <div class="text-6xl">⏱️</div>
          <h2 class="text-3xl font-black text-slate-900 dark:text-slate-100">Time's Up!</h2>
          <p class="text-slate-500 text-sm">Tremendous speed blitz performance!</p>

          <div class="py-4 border-y border-slate-100 dark:border-slate-800">
            <div class="text-xs font-bold text-slate-400 uppercase">Total Correct Answers</div>
            <div class="text-5xl font-black text-amber-500 my-1">${score}</div>
            <div class="text-xs text-slate-400">Personal Best: ${this.state.user.highScores.blitz}</div>
          </div>

          <div class="space-y-3 pt-2">
            <button onclick="App.startSpeedBlitz()" class="w-full py-3.5 bg-amber-500 hover:bg-amber-400 text-slate-950 font-black rounded-2xl text-sm transition shadow-md">
              Play Again ↺
            </button>
            <button onclick="App.showDashboard()" class="w-full py-3 bg-slate-100 dark:bg-slate-800 hover:bg-slate-200 text-slate-700 dark:text-slate-300 font-bold rounded-2xl text-sm transition">
              Back to Dashboard
            </button>
          </div>
        </div>
      </div>
    `;
  },

  // ==========================================
  // MODE 3: BATTLE ARENA (VS AI / PASS & PLAY)
  // ==========================================
  startBattleArena() {
    this.state.currentMode = "battle";
    const b = this.state.battle;
    b.playerScore = 0;
    b.opponentScore = 0;
    b.round = 1;
    b.totalRounds = 5;

    soundManager.playPop();
    this.renderBattleScreen();
    this.nextBattleRound();
  },

  renderBattleScreen() {
    const main = document.getElementById("mainContent");
    if (!main) return;

    main.innerHTML = `
      <div class="max-w-2xl mx-auto space-y-6 animate-fadeIn">
        <div class="flex items-center justify-between p-4 bg-white dark:bg-slate-900 border border-slate-200 dark:border-slate-800 rounded-3xl shadow-sm">
          <button onclick="App.showDashboard()" class="text-xs font-bold text-slate-400 hover:text-slate-600">✕ Exit</button>

          <div class="flex items-center gap-6">
            <div class="text-center">
              <div class="text-xs font-bold text-blue-500 flex items-center gap-1 justify-center">
                <span>${this.state.user.avatar}</span> <span>You</span>
              </div>
              <div id="battleP1Score" class="font-black text-2xl text-slate-800 dark:text-slate-100">0</div>
            </div>

            <div class="text-sm font-black text-purple-600">VS</div>

            <div class="text-center">
              <div class="text-xs font-bold text-rose-500 flex items-center gap-1 justify-center">
                <span>🤖</span> <span>MathBot</span>
              </div>
              <div id="battleP2Score" class="font-black text-2xl text-slate-800 dark:text-slate-100">0</div>
            </div>
          </div>

          <div class="text-xs font-bold text-slate-400">
            Round <span id="battleRoundDisplay">1</span>/5
          </div>
        </div>

        <div id="battleQuestionCard"></div>
      </div>
    `;
  },

  nextBattleRound() {
    const b = this.state.battle;
    const tier = CURRICULUM.tiers.find(t => t.id === this.state.currentTierId) || CURRICULUM.tiers[0];
    const topic = tier.topics[randInt(0, tier.topics.length - 1)];
    b.currentQuestion = generateQuestion(tier.id, topic.id, 1);
    b.p1Answered = false;

    const roundEl = document.getElementById("battleRoundDisplay");
    if (roundEl) roundEl.textContent = b.round;

    const card = document.getElementById("battleQuestionCard");
    if (!card) return;

    const optionsHtml = b.currentQuestion.options.map((opt) => `
      <button onclick="App.handleBattleAnswer('${opt}', this)" class="battle-option-btn p-4 rounded-2xl border-2 border-slate-200 dark:border-slate-700 bg-white dark:bg-slate-900 hover:border-purple-500 font-bold text-lg transition shadow-sm text-center font-mono">
        ${opt}
      </button>
    `).join("");

    card.innerHTML = `
      <div class="space-y-5 animate-scaleUp">
        <div class="bg-white dark:bg-slate-900 border border-slate-200 dark:border-slate-800 rounded-3xl p-6 text-center shadow-lg">
          <div class="text-xs font-bold text-purple-500 uppercase tracking-widest mb-1">Round ${b.round} Duel</div>
          <h3 class="text-2xl font-black text-slate-900 dark:text-slate-100">${b.currentQuestion.question}</h3>
          ${b.currentQuestion.visualContent || ''}
        </div>
        <div class="grid grid-cols-2 gap-3">
          ${optionsHtml}
        </div>
        <div id="battleBotStatus" class="text-center text-xs font-bold text-slate-400 h-5">
          MathBot is calculating...
        </div>
      </div>
    `;
  },

  handleBattleAnswer(selectedVal, btnElement) {
    const b = this.state.battle;
    if (b.p1Answered) return;
    b.p1Answered = true;

    const isCorrect = selectedVal.toString() === b.currentQuestion.correctAnswer.toString();
    const botStatus = document.getElementById("battleBotStatus");

    document.querySelectorAll(".battle-option-btn").forEach(btn => {
      btn.disabled = true;
    });

    if (isCorrect) {
      soundManager.playCorrect();
      b.playerScore++;
      btnElement.classList.add("bg-emerald-500", "text-white");
    } else {
      soundManager.playWrong();
      btnElement.classList.add("bg-rose-500", "text-white");
    }

    const botCorrect = Math.random() < 0.7;
    if (botCorrect) {
      b.opponentScore++;
      if (botStatus) botStatus.textContent = "🤖 MathBot got it right!";
    } else {
      if (botStatus) botStatus.textContent = "🤖 MathBot made a mistake!";
    }

    const p1El = document.getElementById("battleP1Score");
    const p2El = document.getElementById("battleP2Score");
    if (p1El) p1El.textContent = b.playerScore;
    if (p2El) p2El.textContent = b.opponentScore;

    setTimeout(() => {
      b.round++;
      if (b.round <= b.totalRounds) {
        this.nextBattleRound();
      } else {
        this.finishBattle();
      }
    }, 1200);
  },

  finishBattle() {
    const b = this.state.battle;
    const isWin = b.playerScore > b.opponentScore;
    const isTie = b.playerScore === b.opponentScore;

    if (isWin) {
      soundManager.playFanfare();
      confetti.burst(90);
      this.awardXP(50);
      this.unlockBadge("bot_slayer");
    } else {
      soundManager.playWrong();
    }

    const main = document.getElementById("mainContent");
    if (!main) return;

    main.innerHTML = `
      <div class="max-w-md mx-auto space-y-6 text-center animate-scaleUp">
        <div class="p-8 bg-white dark:bg-slate-900 border border-slate-200 dark:border-slate-800 rounded-3xl shadow-xl space-y-4">
          <div class="text-6xl">${isWin ? '🏆' : (isTie ? '🤝' : '🤖')}</div>
          <h2 class="text-3xl font-black text-slate-900 dark:text-slate-100">
            ${isWin ? 'Victory!' : (isTie ? 'It\'s a Tie!' : 'Bot Won This Time!')}
          </h2>
          <p class="text-slate-500 text-sm">Final Score: You ${b.playerScore} - ${b.opponentScore} MathBot</p>

          <div class="space-y-3 pt-2">
            <button onclick="App.startBattleArena()" class="w-full py-3.5 bg-purple-600 hover:bg-purple-700 text-white font-black rounded-2xl text-sm transition shadow-md">
              Rematch ⚔️
            </button>
            <button onclick="App.showDashboard()" class="w-full py-3 bg-slate-100 dark:bg-slate-800 hover:bg-slate-200 text-slate-700 dark:text-slate-300 font-bold rounded-2xl text-sm transition">
              Back to Dashboard
            </button>
          </div>
        </div>
      </div>
    `;
  },

  // ==========================================
  // MODE 4: INTERACTIVE MATH LAB
  // ==========================================
  showMathLab() {
    this.state.currentMode = "lab";
    const main = document.getElementById("mainContent");
    if (!main) return;

    main.innerHTML = `
      <div class="space-y-6 animate-fadeIn">
        <div class="flex items-center justify-between flex-wrap gap-3">
          <button onclick="App.showDashboard()" class="text-xs font-bold text-slate-400 hover:text-slate-600 flex items-center gap-1">
            <span>← Back to Dashboard</span>
          </button>
          <div class="flex flex-wrap gap-2">
            <button onclick="MathLab.setTab('tenframe')" class="px-3.5 py-1.5 rounded-xl text-xs font-bold transition ${MathLab.activeTab === 'tenframe' ? 'bg-emerald-600 text-white' : 'bg-slate-100 dark:bg-slate-800 text-slate-600 dark:text-slate-300'}">🔟 Ten-Frame (5-7)</button>
            <button onclick="MathLab.setTab('fraction')" class="px-3.5 py-1.5 rounded-xl text-xs font-bold transition ${MathLab.activeTab === 'fraction' ? 'bg-amber-600 text-white' : 'bg-slate-100 dark:bg-slate-800 text-slate-600 dark:text-slate-300'}">🍕 Pizza Fractions (8-11)</button>
            <button onclick="MathLab.setTab('balance')" class="px-3.5 py-1.5 rounded-xl text-xs font-bold transition ${MathLab.activeTab === 'balance' ? 'bg-blue-600 text-white' : 'bg-slate-100 dark:bg-slate-800 text-slate-600 dark:text-slate-300'}">⚖️ Equation Balancer (12-14)</button>
            <button onclick="MathLab.setTab('grapher')" class="px-3.5 py-1.5 rounded-xl text-xs font-bold transition ${MathLab.activeTab === 'grapher' ? 'bg-fuchsia-600 text-white' : 'bg-slate-100 dark:bg-slate-800 text-slate-600 dark:text-slate-300'}">📈 Trig & Curves (15-18)</button>
          </div>
        </div>

        <div id="mathLabContent" class="py-2"></div>
      </div>
    `;

    MathLab.render();
  }
};

window.addEventListener("DOMContentLoaded", () => {
  App.init();
});
